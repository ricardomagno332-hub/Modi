package com.god;

import com.god.commands.GodAdminCommands;
import com.god.config.GODConfig;
import com.god.dimensions.DimensionManager;
import com.god.observer.PlayerObserver;
import com.god.recovery.InventoryRecovery;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.function.Consumer;

public class GODMod implements ModInitializer {
    public static final String MOD_ID = "god";
    public static final Logger LOGGER = LoggerFactory.getLogger("GOD");
    public static final Identifier STATUS_REQUEST = new Identifier(MOD_ID, "status_request");
    public static final Identifier STATUS = new Identifier(MOD_ID, "status");

    private static volatile GODRuntime runtime;

    public static GODRuntime runtime() { return runtime; }

    /** Executa uma acao no runtime ativo, isolando excecoes para que os hooks nunca derrubem o servidor. */
    public static void with(Consumer<GODRuntime> action) {
        GODRuntime rt = runtime;
        if (rt == null) return;
        try {
            action.accept(rt);
        } catch (Throwable t) {
            LOGGER.error("Erro em hook do GOD", t);
        }
    }

    @Override
    public void onInitialize() {
        GODConfig.load();

        ServerLifecycleEvents.SERVER_STARTED.register(server -> runtime = new GODRuntime(server));
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            GODRuntime rt = runtime;
            runtime = null;
            if (rt != null) rt.shutdown();
        });
        ServerTickEvents.END_SERVER_TICK.register(server -> with(GODRuntime::tick));

        ServerMessageEvents.CHAT_MESSAGE.register((message, sender, params) ->
                with(rt -> rt.decisions.onChat(sender, message.getSignedContent(), false)));

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> GodAdminCommands.register(dispatcher));

        PlayerObserver.registerHooks();
        DimensionManager.registerHooks();
        InventoryRecovery.registerHooks();

        // Painel in-world: o cliente pede o estado; o servidor responde (somente administradores veem detalhes).
        ServerPlayNetworking.registerGlobalReceiver(STATUS_REQUEST, (server, player, handler, buf, responseSender) -> {
            GODRuntime rt = runtime;
            if (rt == null) return;
            boolean admin = rt.commands.isAdmin(player);
            String json = rt.statusJson(admin);
            if (json.length() > 30000) json = json.substring(0, 30000);
            PacketByteBuf out = PacketByteBufs.create();
            out.writeString(json, 32767);
            ServerPlayNetworking.send(player, STATUS, out);
        });
    }
}
