package com.god;

import com.god.ai.AIManager;
import com.god.ai.DecisionEngine;
import com.god.ai.ToolRegistry;
import com.god.commands.GODCommandManager;
import com.god.config.GODConfig;
import com.god.dimensions.DimensionManager;
import com.god.memory.LongTermMemory;
import com.god.memory.MemoryManager;
import com.god.observer.EventManager;
import com.god.observer.PlayerObserver;
import com.god.observer.WorldObserver;
import com.god.recovery.InventoryRecovery;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.minecraft.server.MinecraftServer;

/** Todos os sistemas do GOD para o servidor em execucao (criado ao iniciar o mundo). */
public final class GODRuntime {
    public final MinecraftServer server;
    public final MemoryManager memory;
    public final EventManager events;
    public final AIManager ai;
    public final InventoryRecovery recovery;
    public final GODCommandManager commands;
    public final ToolRegistry tools;
    public final DecisionEngine decisions;
    public final WorldObserver worldObserver;
    public final PlayerObserver playerObserver;
    public final DimensionManager dimensions;
    private int tick;

    public GODRuntime(MinecraftServer server) {
        this.server = server;
        this.memory = new MemoryManager(server);
        this.events = new EventManager(this);
        this.ai = new AIManager();
        this.recovery = new InventoryRecovery(this);
        this.commands = new GODCommandManager(this);
        this.tools = new ToolRegistry(this);
        this.decisions = new DecisionEngine(this);
        this.worldObserver = new WorldObserver(this);
        this.playerObserver = new PlayerObserver(this);
        this.dimensions = new DimensionManager(this);
        GODMod.LOGGER.info("GOD iniciado (autonomia {}, modelo {}).", GODConfig.get().autonomy, GODConfig.get().model);
    }

    /** Chamado a cada tick do servidor (thread principal). */
    public void tick() {
        tick++;
        GODConfig c = GODConfig.get();
        if (tick % (c.observationIntervalSeconds * 20) == 0) {
            worldObserver.poll();
            playerObserver.poll();
            dimensions.poll();
        }
        if (tick % 20 == 0) {
            commands.tick();
            decisions.tick();
        }
        if (tick % 1200 == 0) memory.saveIfDirty();
    }

    public void shutdown() {
        memory.save();
        GODMod.LOGGER.info("GOD encerrado; memoria salva.");
    }

    /** Estado para o painel in-world. Nunca inclui a API Key. */
    public String statusJson(boolean detailed) {
        GODConfig c = GODConfig.get();
        JsonObject o = new JsonObject();
        o.addProperty("state", ai.state.name());
        o.addProperty("provider", c.provider);
        o.addProperty("model", c.model);
        o.addProperty("autonomy", c.autonomy.name());
        o.addProperty("apiKeySet", !c.resolveApiKey().isBlank());
        o.addProperty("lastInteraction", ai.lastInteraction);
        o.addProperty("lastDecision", ai.lastDecision);
        o.addProperty("lastAction", ai.lastAction);
        o.addProperty("lastError", ai.lastError);
        o.addProperty("autonomousTurns", decisions.autonomousTurns);
        o.addProperty("userTurns", decisions.userTurns);
        o.addProperty("commandsRun", commands.executedCount);
        o.addProperty("pending", commands.pendingCount());
        o.addProperty("requests", ai.requests.get());
        o.addProperty("tokens", ai.tokensUsed.get());
        JsonArray mem = new JsonArray();
        if (detailed) {
            for (LongTermMemory.Entry e : memory.longTerm().recent(5)) {
                mem.add(e.text.length() > 120 ? e.text.substring(0, 120) + "..." : e.text);
            }
        }
        o.add("memories", mem);
        return o.toString();
    }
}
