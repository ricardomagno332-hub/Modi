package com.god.commands;

import com.god.GODMod;
import com.god.GODRuntime;
import com.god.config.GODConfig;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * GOD Command Manager: recebe a intencao da IA, classifica, aplica limites e confirmacao administrativa,
 * executa pelo sistema real de comandos (thread principal) e devolve o resultado para a IA.
 */
public class GODCommandManager {
    public enum Status { EXECUTED, FAILED, PENDING_CONFIRMATION, BLOCKED }

    public record Result(Status status, String output, int returnValue, String id) {
        public String toToolString() {
            return switch (status) {
                case EXECUTED -> "EXECUTADO (retorno=" + returnValue + ")" + (output.isBlank() ? "" : ": " + output);
                case FAILED -> "FALHOU: " + output;
                case PENDING_CONFIRMATION -> "AGUARDANDO_CONFIRMACAO id=" + id
                        + ": um administrador precisa aprovar (" + output + "). NAO repita o comando; avise o jogador.";
                case BLOCKED -> "BLOQUEADO: " + output;
            };
        }
    }

    private static final class Pending {
        String id;
        String command;
        UUID playerId;
        String why;
        long expiresAt;
    }

    private final GODRuntime rt;
    private final Deque<Long> recent = new ArrayDeque<>();
    private final Map<String, Pending> pending = new LinkedHashMap<>();
    private int counter = 1;
    public int executedCount;

    public GODCommandManager(GODRuntime rt) { this.rt = rt; }

    public int pendingCount() { return pending.size(); }

    /** Ponto de entrada para comandos pedidos pela IA. Thread principal. */
    public Result submit(String raw, ServerPlayerEntity ctxPlayer, boolean userInitiated, String reason) {
        GODConfig c = GODConfig.get();
        String cmd = raw == null ? "" : raw.trim();
        if (cmd.startsWith("/")) cmd = cmd.substring(1).trim();
        if (cmd.isEmpty() || cmd.contains("\n") || cmd.contains("\r")) return blocked("comando vazio ou com varias linhas");
        if (!c.allowCommands) return blocked("o jogador desativou o acesso a comandos");

        CommandRisk.Risk risk = CommandRisk.analyze(rt.server, cmd, ctxPlayer, c);
        String denied = categoryDenied(risk.category(), c);
        if (denied != null) return blocked(denied);
        if (risk.category() == CommandRisk.Category.SERVER_ADMIN && !c.allowServerAdminCommands) {
            return blocked("comandos de administracao do servidor (" + risk.root() + ") estao desativados na config");
        }
        boolean needsConfirm = risk.needsConfirmation() || risk.category() == CommandRisk.Category.SERVER_ADMIN;
        if (needsConfirm) {
            String why = risk.reason().isBlank() ? "comando de administracao do servidor" : risk.reason();
            return queue(cmd, ctxPlayer, why);
        }
        if (!rateOk()) return blocked("limite de " + c.maxCommandsPerMinute + " comandos por minuto atingido");
        return run(cmd, ctxPlayer);
    }

    private String categoryDenied(CommandRisk.Category cat, GODConfig c) {
        return switch (cat) {
            case BLOCKS -> c.allowBlockModification ? null : "modificacao de blocos desativada pelo jogador";
            case SUMMON -> c.allowEntitySummon ? null : "invocacao de entidades desativada pelo jogador";
            case WEATHER -> c.allowWeatherControl ? null : "controle climatico desativado pelo jogador";
            case ITEMS -> c.allowItemGiving ? null : "entrega de itens desativada pelo jogador";
            case TELEPORT -> c.allowTeleport ? null : "teletransporte desativado pelo jogador";
            default -> null;
        };
    }

    private boolean rateOk() {
        long now = System.currentTimeMillis();
        while (!recent.isEmpty() && now - recent.peekFirst() > 60_000) recent.pollFirst();
        if (recent.size() >= GODConfig.get().maxCommandsPerMinute) return false;
        recent.addLast(now);
        return true;
    }

    private Result run(String cmd, ServerPlayerEntity ctxPlayer) {
        CommandExecutor.ExecResult r = CommandExecutor.execute(rt.server, ctxPlayer, cmd);
        executedCount++;
        GODMod.LOGGER.info("[GOD] /{} -> {}{}", cmd, r.success() ? "ok" : "falhou", r.output().isBlank() ? "" : " (" + r.output() + ")");
        rt.ai.lastAction = "/" + cmd + (r.success() ? "" : " (falhou)");
        rt.events.logAction("/" + cmd + " -> " + (r.success() ? "ok" : "falhou"));
        return new Result(r.success() ? Status.EXECUTED : Status.FAILED, r.output(), r.returnValue(), null);
    }

    private Result blocked(String why) { return new Result(Status.BLOCKED, why, 0, null); }

    // ---------- confirmacao administrativa ----------
    private Result queue(String cmd, ServerPlayerEntity ctxPlayer, String why) {
        Pending p = new Pending();
        p.id = Integer.toString(counter++, 36);
        p.command = cmd;
        p.playerId = ctxPlayer == null ? null : ctxPlayer.getUuid();
        p.why = why;
        p.expiresAt = System.currentTimeMillis() + GODConfig.get().confirmationTimeoutSeconds * 1000L;
        pending.put(p.id, p);
        notifyAdmins(p);
        GODMod.LOGGER.info("[GOD] Comando aguardando confirmacao #{}: /{} ({})", p.id, cmd, why);
        return new Result(Status.PENDING_CONFIRMATION, why, 0, p.id);
    }

    private void notifyAdmins(Pending p) {
        MutableText msg = Text.literal("[GOD] Aprovacao #" + p.id + ": ").formatted(Formatting.GOLD)
                .append(Text.literal("/" + p.command).formatted(Formatting.WHITE))
                .append(Text.literal(" (" + p.why + ") ").formatted(Formatting.GRAY))
                .append(Text.literal("[Aprovar]").setStyle(Style.EMPTY.withColor(Formatting.GREEN)
                        .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/god confirm " + p.id))))
                .append(Text.literal(" "))
                .append(Text.literal("[Negar]").setStyle(Style.EMPTY.withColor(Formatting.RED)
                        .withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/god deny " + p.id))));
        for (ServerPlayerEntity pl : rt.server.getPlayerManager().getPlayerList()) {
            if (isAdmin(pl)) pl.sendMessage(msg);
        }
    }

    public boolean isAdmin(ServerPlayerEntity pl) {
        return pl.getCommandSource().hasPermissionLevel(2) || rt.server.isHost(pl.getGameProfile());
    }

    /** Aprova ou nega um comando pendente. Retorna texto para o administrador. */
    public String decide(String id, boolean approve, String adminName) {
        Pending p = pending.remove(id);
        if (p == null) return "Nenhum comando pendente com id " + id + " (pode ter expirado).";
        if (!approve) {
            rt.events.record("ADMIN", 5, adminName, adminName + " NEGOU o comando /" + p.command);
            return "Comando negado: /" + p.command;
        }
        ServerPlayerEntity ctx = p.playerId == null ? null : rt.server.getPlayerManager().getPlayer(p.playerId);
        Result r = run(p.command, ctx);
        rt.events.record("ADMIN", 5, adminName, adminName + " APROVOU /" + p.command + " -> " + r.toToolString());
        return "Executado: /" + p.command + " -> " + r.toToolString();
    }

    public List<String> describePending() {
        List<String> out = new ArrayList<>();
        for (Pending p : pending.values()) out.add("#" + p.id + " /" + p.command + " (" + p.why + ")");
        return out;
    }

    /** Expira confirmacoes antigas. */
    public void tick() {
        if (pending.isEmpty()) return;
        long now = System.currentTimeMillis();
        Iterator<Pending> it = pending.values().iterator();
        while (it.hasNext()) {
            Pending p = it.next();
            if (now > p.expiresAt) {
                it.remove();
                rt.events.record("ADMIN", 3, null, "Confirmacao #" + p.id + " expirou sem resposta: /" + p.command);
            }
        }
    }
}
