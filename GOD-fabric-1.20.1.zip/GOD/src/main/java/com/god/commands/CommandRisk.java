package com.god.commands;

import com.god.config.GODConfig;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.Arrays;
import java.util.Locale;
import java.util.Set;

/**
 * Classificador de risco. NAO e uma lista de comandos permitidos: todo comando vanilla pode ser executado.
 * Ele apenas decide (a) a categoria, para respeitar os interruptores do "World Control", e
 * (b) se a acao e destrutiva/afeta outros jogadores e portanto exige confirmacao administrativa.
 */
public final class CommandRisk {
    private CommandRisk() { }

    public enum Category { GENERAL, BLOCKS, SUMMON, WEATHER, ITEMS, TELEPORT, SERVER_ADMIN }

    public record Risk(String root, Category category, boolean needsConfirmation, String reason) { }

    private static final Set<String> ADMIN = Set.of("stop", "op", "deop", "ban", "ban-ip", "pardon", "pardon-ip",
            "whitelist", "kick", "save-all", "save-on", "save-off", "reload", "debug", "perf", "publish",
            "setidletimeout", "jfr", "datapack");
    private static final Set<String> BLOCKS = Set.of("setblock", "fill", "clone", "fillbiome", "place");
    private static final Set<String> ITEMS = Set.of("give", "loot");
    private static final Set<String> TELEPORT = Set.of("tp", "teleport", "spreadplayers");
    private static final Set<String> TARGETS_PLAYERS = Set.of("give", "tp", "teleport", "effect", "clear", "kill",
            "gamemode", "xp", "experience", "enchant", "attribute", "damage", "spreadplayers", "advancement", "spawnpoint");
    private static final Set<String> MUTATING = Set.of("kill", "clear", "fill", "setblock", "summon", "clone", "tp",
            "teleport", "give", "effect", "damage", "data", "gamemode", "enchant", "attribute", "xp", "experience");
    private static final Set<String> DANGEROUS_ENTITIES = Set.of("tnt", "tnt_minecart", "wither", "ender_dragon",
            "end_crystal", "lightning_bolt", "warden");
    private static final Set<String> WORLD_STATE = Set.of("gamerule", "worldborder", "difficulty", "forceload", "setworldspawn");

    public static Risk analyze(MinecraftServer server, String command, ServerPlayerEntity ctx, GODConfig cfg) {
        String[] t = command.trim().split("\\s+");
        String root = t[0].toLowerCase(Locale.ROOT);
        if (root.contains(":")) root = root.substring(root.indexOf(':') + 1);

        // execute ... run <cmd>: classifica o comando final (recursivamente) e avalia o seletor do prefixo.
        if (root.equals("execute")) {
            int run = -1;
            for (int i = 1; i < t.length; i++) if (t[i].equals("run")) { run = i; break; }
            if (run < 0 || run == t.length - 1) return new Risk("execute", Category.GENERAL, false, "");
            String prefix = String.join(" ", Arrays.copyOfRange(t, 1, run));
            String rest = String.join(" ", Arrays.copyOfRange(t, run + 1, t.length));
            Risk inner = analyze(server, rest, ctx, cfg);
            if (cfg.requireConfirmationForDestructive && hasBroadSelector(prefix) && MUTATING.contains(inner.root())) {
                return new Risk(inner.root(), inner.category(), true, "execute com seletor amplo (@a/@e) alterando o mundo");
            }
            return inner;
        }

        Category cat = ADMIN.contains(root) ? Category.SERVER_ADMIN
                : BLOCKS.contains(root) ? Category.BLOCKS
                : root.equals("summon") ? Category.SUMMON
                : root.equals("weather") ? Category.WEATHER
                : ITEMS.contains(root) ? Category.ITEMS
                : TELEPORT.contains(root) ? Category.TELEPORT
                : Category.GENERAL;

        String why = null;
        if (cfg.requireConfirmationForDestructive) {
            switch (root) {
                case "kill" -> { if (t.length > 1 && broadToken(t[1])) why = "kill em massa (@a/@e)"; }
                case "clear" -> why = "remove itens do inventario";
                case "fill", "clone", "fillbiome" -> {
                    if (t.length >= 7) {
                        double vol = volume(t);
                        if (Double.isNaN(vol)) why = "area nao calculavel (coordenadas mistas ou locais)";
                        else if (vol > cfg.maxFillVolume) why = "volume de " + (long) vol + " blocos excede o limite de " + cfg.maxFillVolume;
                    }
                }
                case "summon" -> {
                    if (t.length > 1) {
                        String id = t[1].toLowerCase(Locale.ROOT).replace("minecraft:", "");
                        int br = id.indexOf('{');
                        if (br >= 0) id = id.substring(0, br);
                        if (DANGEROUS_ENTITIES.contains(id)) why = "invocacao perigosa (" + id + ")";
                    }
                }
                case "data" -> { if (t.length > 1 && !t[1].equals("get")) why = "altera dados NBT"; }
                default -> { }
            }
            if (why == null && WORLD_STATE.contains(root)) {
                boolean readOnly = (root.equals("gamerule") && t.length <= 2)
                        || (root.equals("worldborder") && t.length > 1 && t[1].equals("get"))
                        || (root.equals("difficulty") && t.length < 2)
                        || (root.equals("forceload") && t.length > 1 && t[1].equals("query"));
                if (!readOnly) why = "altera regra/estado global do mundo (" + root + ")";
            }
        }
        if (why == null && cfg.confirmWhenAffectingOthers && TARGETS_PLAYERS.contains(root)) {
            String other = otherPlayerTarget(server, t, ctx);
            if (other != null) why = "afeta outro(s) jogador(es): " + other;
        }
        return new Risk(root, cat, why != null, why == null ? "" : why);
    }

    private static boolean broadToken(String tok) {
        return tok.startsWith("@a") || (tok.startsWith("@e") && !tok.contains("type="));
    }

    private static boolean hasBroadSelector(String text) {
        for (String tok : text.split("\\s+")) if (broadToken(tok)) return true;
        return false;
    }

    private static String otherPlayerTarget(MinecraftServer server, String[] t, ServerPlayerEntity ctx) {
        for (int i = 1; i < t.length; i++) {
            String tok = t[i];
            if (tok.startsWith("@a")) return "@a";
            if (tok.startsWith("@r")) return "@r";
            if (tok.startsWith("@e") && !tok.contains("type=")) return "@e";
            if (ctx != null) {
                for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                    if (p != ctx && p.getGameProfile().getName().equalsIgnoreCase(tok)) return p.getGameProfile().getName();
                }
            }
        }
        return null;
    }

    private record Coord(boolean rel, double v) { }

    private static Coord coord(String s) {
        try {
            if (s.startsWith("^")) return null;
            if (s.startsWith("~")) return new Coord(true, s.length() == 1 ? 0 : Double.parseDouble(s.substring(1)));
            return new Coord(false, Double.parseDouble(s));
        } catch (NumberFormatException e) { return null; }
    }

    /** Volume da regiao (x1 y1 z1 x2 y2 z2) ou NaN se nao for possivel calcular. */
    private static double volume(String[] t) {
        double vol = 1;
        for (int i = 0; i < 3; i++) {
            Coord a = coord(t[1 + i]);
            Coord b = coord(t[4 + i]);
            if (a == null || b == null || a.rel() != b.rel()) return Double.NaN;
            vol *= Math.abs(a.v() - b.v()) + 1;
        }
        return vol;
    }
}
