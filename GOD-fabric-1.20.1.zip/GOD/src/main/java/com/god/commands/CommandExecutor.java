package com.god.commands;

import com.god.GODMod;
import com.god.config.GODConfig;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.ParseResults;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandOutput;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/**
 * Executa UM comando pelo dispatcher real do Minecraft e captura a saida (feedback e erros).
 * Deve ser chamado somente na thread principal do servidor.
 */
public final class CommandExecutor {
    private CommandExecutor() { }

    public record ExecResult(boolean success, int returnValue, String output) { }

    /** Coleta as mensagens que o comando enviaria ao "console" do GOD. */
    private static final class CapturingOutput implements CommandOutput {
        private final List<String> lines = new ArrayList<>();

        @Override public void sendMessage(Text message) {
            if (lines.size() < 20) lines.add(message.getString());
        }
        @Override public boolean shouldReceiveFeedback() { return true; }
        @Override public boolean shouldTrackOutput() { return true; }
        // true: administradores online veem "[GOD: ...]" no chat (transparencia das acoes)
        @Override public boolean shouldBroadcastConsoleToOps() { return true; }

        String joined() {
            String s = String.join(" | ", lines);
            return s.length() > 1500 ? s.substring(0, 1500) + "..." : s;
        }
    }

    public static ExecResult execute(MinecraftServer server, ServerPlayerEntity ctx, String command) {
        CapturingOutput out = new CapturingOutput();
        ServerWorld world = ctx != null ? ctx.getServerWorld() : server.getOverworld();
        Vec3d pos = ctx != null ? ctx.getPos() : Vec3d.ofCenter(world.getSpawnPos());
        Vec2f rot = ctx != null ? ctx.getRotationClient() : Vec2f.ZERO;
        int level = GODConfig.get().commandPermissionLevel;
        ServerCommandSource source = new ServerCommandSource(out, pos, rot, world, level, "GOD", Text.literal("GOD"), server, null);
        CommandDispatcher<ServerCommandSource> dispatcher = server.getCommandManager().getDispatcher();
        try {
            ParseResults<ServerCommandSource> parse = dispatcher.parse(command, source);
            int result = dispatcher.execute(parse);
            return new ExecResult(true, result, out.joined());
        } catch (CommandSyntaxException e) {
            String msg = e.getMessage() == null ? "erro de sintaxe" : e.getMessage();
            return new ExecResult(false, 0, "Erro de comando: " + msg + (out.lines.isEmpty() ? "" : " | " + out.joined()));
        } catch (Exception e) {
            GODMod.LOGGER.warn("Excecao ao executar comando do GOD: {}", e.toString());
            return new ExecResult(false, 0, "Excecao: " + e.getClass().getSimpleName());
        }
    }
}
