package com.god.commands;

import com.god.GODMod;
import com.god.GODRuntime;
import com.god.config.GODConfig;
import com.god.memory.LongTermMemory;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

/** Comandos /god para jogadores (ask, status) e administradores (confirm, deny, memory, autonomy...). */
public final class GodAdminCommands {
    private GodAdminCommands() { }

    public static boolean isAdmin(ServerCommandSource s) {
        if (s.hasPermissionLevel(2)) return true;
        return s.getEntity() instanceof ServerPlayerEntity p && s.getServer().isHost(p.getGameProfile());
    }

    public static void register(CommandDispatcher<ServerCommandSource> d) {
        d.register(CommandManager.literal("god")
                .executes(c -> status(c.getSource()))
                .then(CommandManager.literal("status").executes(c -> status(c.getSource())))
                .then(CommandManager.literal("ask")
                        .then(CommandManager.argument("mensagem", StringArgumentType.greedyString()).executes(GodAdminCommands::ask)))
                .then(CommandManager.literal("confirm").requires(GodAdminCommands::isAdmin)
                        .then(CommandManager.argument("id", StringArgumentType.word()).executes(c -> decide(c, true))))
                .then(CommandManager.literal("deny").requires(GodAdminCommands::isAdmin)
                        .then(CommandManager.argument("id", StringArgumentType.word()).executes(c -> decide(c, false))))
                .then(CommandManager.literal("pending").requires(GodAdminCommands::isAdmin).executes(GodAdminCommands::pending))
                .then(CommandManager.literal("autonomy").requires(GodAdminCommands::isAdmin)
                        .then(CommandManager.argument("nivel", StringArgumentType.word()).executes(GodAdminCommands::autonomy)))
                .then(CommandManager.literal("reload").requires(GodAdminCommands::isAdmin).executes(c -> {
                    GODConfig.load();
                    c.getSource().sendFeedback(() -> Text.literal("[GOD] Configuracao recarregada."), false);
                    return 1;
                }))
                .then(CommandManager.literal("recover").requires(GodAdminCommands::isAdmin)
                        .then(CommandManager.argument("jogador", EntityArgumentType.player()).executes(GodAdminCommands::recover)))
                .then(CommandManager.literal("memory").requires(GodAdminCommands::isAdmin)
                        .then(CommandManager.literal("list").executes(GodAdminCommands::memList))
                        .then(CommandManager.literal("forget")
                                .then(CommandManager.argument("id", StringArgumentType.word()).executes(GodAdminCommands::memForget)))
                        .then(CommandManager.literal("clear").executes(GodAdminCommands::memClear))));
    }

    private static GODRuntime rt(ServerCommandSource s) {
        GODRuntime rt = GODMod.runtime();
        if (rt == null) s.sendError(Text.literal("[GOD] Ainda nao inicializado."));
        return rt;
    }

    private static int status(ServerCommandSource s) {
        GODRuntime rt = rt(s);
        if (rt == null) return 0;
        GODConfig c = GODConfig.get();
        String msg = "[GOD] estado=" + rt.ai.state + " | autonomia=" + c.autonomy + " | modelo=" + c.model
                + " | chave=" + (c.resolveApiKey().isBlank() ? "NAO configurada" : "configurada")
                + " | pendentes=" + rt.commands.pendingCount();
        s.sendFeedback(() -> Text.literal(msg), false);
        return 1;
    }

    private static int ask(CommandContext<ServerCommandSource> c) throws CommandSyntaxException {
        GODRuntime rt = rt(c.getSource());
        if (rt == null) return 0;
        ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
        String msg = StringArgumentType.getString(c, "mensagem");
        rt.memory.addConversation("user", p.getGameProfile().getName(), msg);
        rt.decisions.onChat(p, msg, true);
        return 1;
    }

    private static int decide(CommandContext<ServerCommandSource> c, boolean approve) {
        GODRuntime rt = rt(c.getSource());
        if (rt == null) return 0;
        String result = rt.commands.decide(StringArgumentType.getString(c, "id"), approve, c.getSource().getName());
        c.getSource().sendFeedback(() -> Text.literal("[GOD] " + result), true);
        return 1;
    }

    private static int pending(CommandContext<ServerCommandSource> c) {
        GODRuntime rt = rt(c.getSource());
        if (rt == null) return 0;
        var list = rt.commands.describePending();
        c.getSource().sendFeedback(() -> Text.literal(list.isEmpty() ? "[GOD] Nenhum comando pendente." : "[GOD] Pendentes: " + String.join("; ", list)), false);
        return list.size();
    }

    private static int autonomy(CommandContext<ServerCommandSource> c) {
        try {
            GODConfig.AutonomyLevel lvl = GODConfig.AutonomyLevel.valueOf(StringArgumentType.getString(c, "nivel").toUpperCase());
            GODConfig.get().autonomy = lvl;
            GODConfig.save();
            c.getSource().sendFeedback(() -> Text.literal("[GOD] Autonomia: " + lvl), true);
            return 1;
        } catch (IllegalArgumentException e) {
            c.getSource().sendError(Text.literal("[GOD] Niveis: OFF, LOW, MEDIUM, HIGH"));
            return 0;
        }
    }

    private static int recover(CommandContext<ServerCommandSource> c) throws CommandSyntaxException {
        GODRuntime rt = rt(c.getSource());
        if (rt == null) return 0;
        ServerPlayerEntity target = EntityArgumentType.getPlayer(c, "jogador");
        String r = rt.recovery.deliver(target, null);
        c.getSource().sendFeedback(() -> Text.literal("[GOD] " + r), true);
        return 1;
    }

    private static int memList(CommandContext<ServerCommandSource> c) {
        GODRuntime rt = rt(c.getSource());
        if (rt == null) return 0;
        var list = rt.memory.longTerm().recent(15);
        if (list.isEmpty()) c.getSource().sendFeedback(() -> Text.literal("[GOD] Memoria vazia."), false);
        for (LongTermMemory.Entry e : list) {
            String line = "[" + e.id + "] (" + e.type + ", imp " + e.importance + ") " + e.text;
            c.getSource().sendFeedback(() -> Text.literal(line), false);
        }
        return list.size();
    }

    private static int memForget(CommandContext<ServerCommandSource> c) {
        GODRuntime rt = rt(c.getSource());
        if (rt == null) return 0;
        boolean ok = rt.memory.longTerm().remove(StringArgumentType.getString(c, "id"));
        rt.memory.markDirty();
        c.getSource().sendFeedback(() -> Text.literal(ok ? "[GOD] Memoria apagada." : "[GOD] Id nao encontrado."), false);
        return ok ? 1 : 0;
    }

    private static int memClear(CommandContext<ServerCommandSource> c) {
        GODRuntime rt = rt(c.getSource());
        if (rt == null) return 0;
        rt.memory.clearLongTerm();
        c.getSource().sendFeedback(() -> Text.literal("[GOD] Memoria de longo prazo apagada."), true);
        return 1;
    }
}
