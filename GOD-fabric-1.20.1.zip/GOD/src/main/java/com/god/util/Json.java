package com.god.util;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.List;

/** Helpers tolerantes para ler argumentos JSON vindos da IA. */
public final class Json {
    private Json() { }

    public static String str(JsonObject o, String k, String def) {
        try {
            JsonElement e = o.get(k);
            return e == null || e.isJsonNull() ? def : e.getAsString();
        } catch (Exception ex) { return def; }
    }

    public static double num(JsonObject o, String k, double def) {
        try {
            JsonElement e = o.get(k);
            return e == null || e.isJsonNull() ? def : e.getAsDouble();
        } catch (Exception ex) { return def; }
    }

    public static int integer(JsonObject o, String k, int def) { return (int) Math.round(num(o, k, def)); }

    public static List<String> strList(JsonObject o, String k) {
        List<String> out = new ArrayList<>();
        try {
            JsonElement e = o.get(k);
            if (e != null && e.isJsonArray()) {
                for (JsonElement x : (JsonArray) e) out.add(x.getAsString());
            }
        } catch (Exception ignored) { }
        return out;
    }

    public static String cut(String s, int max) {
        if (s == null) return "";
        return s.length() <= max ? s : s.substring(0, max) + "...";
    }
}
