package com.god.recovery;

import com.god.GODMod;
import com.god.GODRuntime;
import com.god.config.GODConfig;
import com.god.memory.MemoryManager;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtIo;
import net.minecraft.nbt.NbtList;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Box;
import net.minecraft.world.GameRules;
import net.minecraft.world.World;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Recuperacao de inventario: grava o inventario no momento da morte, confirma a morte no respawn e entrega
 * os itens UMA unica vez (marcado como entregue e salvo ANTES de entregar, para nunca duplicar).
 * Alem disso, remove do mundo os itens dropados que correspondem ao snapshot (melhor esforco).
 */
public class InventoryRecovery {
    public static class Snapshot {
        public String id;
        public String playerUuid;
        public String playerName;
        public long time;
        public String dimension;
        public double x, y, z;
        public String data;        // NBT comprimido em Base64
        public int stackCount;
        public String summary;
        public boolean confirmed;  // morte confirmada pelo respawn
        public boolean delivered;
    }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final int MAX_PER_PLAYER = 10;

    private final GODRuntime rt;
    private final List<Snapshot> snapshots = new ArrayList<>();
    private final Path file;
    private int counter = 1;

    public InventoryRecovery(GODRuntime rt) {
        this.rt = rt;
        this.file = rt.memory.dir().resolve("recovery.json");
        load();
    }

    public static void registerHooks() {
        // O inventario ainda esta intacto quando a morte e anunciada.
        ServerLivingEntityEvents.ALLOW_DEATH.register((entity, source, amount) -> {
            if (entity instanceof ServerPlayerEntity p) GODMod.with(rt -> rt.recovery.onDeath(p));
            return true;
        });
        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
            if (!alive) GODMod.with(rt -> rt.recovery.onRespawn(newPlayer));
        });
    }

    // ---------- registro ----------
    public void onDeath(ServerPlayerEntity p) {
        if (!GODConfig.get().allowInventoryRecovery) return;
        if (rt.server.getGameRules().getBoolean(GameRules.KEEP_INVENTORY)) return;
        try {
            NbtList list = new NbtList();
            p.getInventory().writeNbt(list);
            if (list.isEmpty()) return;
            NbtCompound root = new NbtCompound();
            root.put("Items", list);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            NbtIo.writeCompressed(root, bos);

            Snapshot s = new Snapshot();
            s.id = "inv" + System.currentTimeMillis() % 100000 + "-" + counter++;
            s.playerUuid = p.getUuidAsString();
            s.playerName = p.getGameProfile().getName();
            s.time = System.currentTimeMillis();
            s.dimension = p.getServerWorld().getRegistryKey().getValue().toString();
            s.x = p.getX();
            s.y = p.getY();
            s.z = p.getZ();
            s.data = Base64.getEncoder().encodeToString(bos.toByteArray());
            List<ItemStack> stacks = decode(s);
            s.stackCount = stacks.size();
            s.summary = summarize(stacks);
            snapshots.add(s);
            prune(p.getUuidAsString());
            save();
        } catch (Exception e) {
            GODMod.LOGGER.error("Falha ao gravar snapshot de inventario: {}", e.toString());
        }
    }

    public void onRespawn(ServerPlayerEntity p) {
        Snapshot latest = null;
        long now = System.currentTimeMillis();
        for (Snapshot s : snapshots) {
            if (s.playerUuid.equals(p.getUuidAsString()) && !s.delivered && !s.confirmed && now - s.time < 5 * 60_000L) latest = s;
        }
        if (latest == null) return;
        latest.confirmed = true;
        save();
        rt.events.record("RESPAWN", 7, latest.playerName,
                latest.playerName + " renasceu. Snapshot de inventario disponivel id=" + latest.id + " (" + latest.stackCount + " pilhas: " + latest.summary + ")");
    }

    public int pendingCount(UUID player) {
        int n = 0;
        for (Snapshot s : snapshots) if (s.playerUuid.equals(player.toString()) && s.confirmed && !s.delivered) n++;
        return n;
    }

    public String describePending(UUID player) {
        StringBuilder sb = new StringBuilder();
        for (Snapshot s : snapshots) {
            if (s.playerUuid.equals(player.toString()) && s.confirmed && !s.delivered) {
                sb.append(s.id).append(" (").append(s.stackCount).append(" pilhas, ").append(s.dimension).append(") ");
            }
        }
        return sb.length() == 0 ? "nenhum" : sb.toString().trim();
    }

    // ---------- entrega ----------
    public String deliver(ServerPlayerEntity p, String snapshotId) {
        if (!GODConfig.get().allowInventoryRecovery) return "BLOQUEADO: recuperacao de inventario desativada";
        if (!p.isAlive()) return "ERRO: jogador esta morto";
        Snapshot s = null;
        for (Snapshot c : snapshots) {
            if (!c.playerUuid.equals(p.getUuidAsString()) || c.delivered || !c.confirmed) continue;
            if (snapshotId == null || snapshotId.isBlank()) { if (s == null || c.time > s.time) s = c; }
            else if (c.id.equals(snapshotId)) s = c;
        }
        if (s == null) return "ERRO: nenhum snapshot confirmado e pendente para " + p.getGameProfile().getName();

        // Marca como entregue e persiste ANTES de dar os itens (protecao contra duplicacao).
        s.delivered = true;
        try {
            writeFile();
        } catch (Exception e) {
            s.delivered = false;
            return "ERRO: nao foi possivel salvar o estado; entrega cancelada por seguranca";
        }
        try {
            List<ItemStack> stacks = decode(s);
            int removed = removeDrops(s, stacks);
            int given = 0;
            for (ItemStack st : stacks) {
                if (st.isEmpty()) continue;
                if (st.getItem() instanceof ArmorItem a && p.getEquippedStack(a.getSlotType()).isEmpty()) {
                    p.equipStack(a.getSlotType(), st);
                } else {
                    p.getInventory().offerOrDrop(st);
                }
                given++;
            }
            p.playerScreenHandler.sendContentUpdates();
            rt.ai.lastAction = "inventario devolvido a " + p.getGameProfile().getName();
            rt.events.logAction("Inventario " + s.id + " devolvido a " + p.getGameProfile().getName());
            return "OK: " + given + " pilhas devolvidas (" + removed + " itens dropados removidos do mundo para evitar duplicacao)";
        } catch (Exception e) {
            GODMod.LOGGER.error("Falha na entrega de inventario: {}", e.toString());
            return "ERRO: falha ao devolver itens (snapshot marcado como entregue para evitar duplicacao; use /god recover se necessario)";
        }
    }

    /** Remove do local da morte os itens dropados equivalentes ao snapshot (melhor esforco). */
    private int removeDrops(Snapshot s, List<ItemStack> stacks) {
        ServerWorld world = rt.server.getWorld(RegistryKey.of(RegistryKeys.WORLD, new Identifier(s.dimension)));
        if (world == null) return 0;
        Map<String, Integer> remaining = new HashMap<>();
        for (ItemStack st : stacks) remaining.merge(key(st), st.getCount(), Integer::sum);
        Box box = new Box(s.x - 12, s.y - 12, s.z - 12, s.x + 12, s.y + 12, s.z + 12);
        int removed = 0;
        for (ItemEntity ie : world.getEntitiesByClass(ItemEntity.class, box, e -> true)) {
            ItemStack st = ie.getStack();
            String k = key(st);
            int left = remaining.getOrDefault(k, 0);
            if (left <= 0) continue;
            int take = Math.min(left, st.getCount());
            if (take >= st.getCount()) ie.discard(); else st.decrement(take);
            remaining.put(k, left - take);
            removed += take;
        }
        return removed;
    }

    private static String key(ItemStack st) {
        return Registries.ITEM.getId(st.getItem()) + String.valueOf(st.getNbt());
    }

    // ---------- util ----------
    private static List<ItemStack> decode(Snapshot s) throws Exception {
        byte[] bytes = Base64.getDecoder().decode(s.data);
        NbtCompound root = NbtIo.readCompressed(new ByteArrayInputStream(bytes));
        NbtList list = root.getList("Items", NbtElement.COMPOUND_TYPE);
        List<ItemStack> out = new ArrayList<>();
        for (int i = 0; i < list.size(); i++) {
            ItemStack st = ItemStack.fromNbt(list.getCompound(i));
            if (!st.isEmpty()) out.add(st);
        }
        return out;
    }

    private static String summarize(List<ItemStack> stacks) {
        Map<String, Integer> m = new HashMap<>();
        for (ItemStack st : stacks) m.merge(Registries.ITEM.getId(st.getItem()).getPath(), st.getCount(), Integer::sum);
        StringBuilder sb = new StringBuilder();
        m.entrySet().stream().sorted((a, b) -> b.getValue() - a.getValue()).limit(6)
                .forEach(e -> sb.append(e.getKey()).append(" x").append(e.getValue()).append(", "));
        return sb.length() > 2 ? sb.substring(0, sb.length() - 2) : "-";
    }

    private void prune(String uuid) {
        long now = System.currentTimeMillis();
        snapshots.removeIf(x -> !x.confirmed && !x.delivered && now - x.time > 10 * 60_000L);
        List<Snapshot> mine = new ArrayList<>();
        for (Snapshot x : snapshots) if (x.playerUuid.equals(uuid)) mine.add(x);
        while (mine.size() > MAX_PER_PLAYER) snapshots.remove(mine.remove(0));
    }

    private void load() {
        try {
            if (Files.exists(file)) {
                Snapshot[] arr = GSON.fromJson(Files.readString(file, StandardCharsets.UTF_8), Snapshot[].class);
                if (arr != null) snapshots.addAll(List.of(arr));
            }
        } catch (Exception e) {
            GODMod.LOGGER.error("Falha ao carregar recovery.json: {}", e.toString());
        }
    }

    private void writeFile() throws Exception {
        Files.createDirectories(file.getParent());
        MemoryManager.atomicWrite(file, GSON.toJson(snapshots));
    }

    private void save() {
        try { writeFile(); } catch (Exception e) { GODMod.LOGGER.error("Falha ao salvar recovery.json: {}", e.toString()); }
    }
}
