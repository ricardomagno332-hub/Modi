package com.god.dimensions;

import com.god.GODMod;
import com.god.GODRuntime;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityWorldChangeEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.entity.boss.dragon.EnderDragonEntity;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.structure.StructureStart;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;
import net.minecraft.world.gen.structure.Structure;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/** Reconhece dimensoes e estruturas: Nether, End, fortalezas, bastioes, dragao, cidades do End etc. */
public class DimensionManager {
    private final GODRuntime rt;
    private int polls;
    private final Set<String> dragonSeen = new HashSet<>();

    // id da estrutura -> {nome amigavel, importancia}
    private static final Map<String, Object[]> STRUCTURES = Map.ofEntries(
            Map.entry("fortress", new Object[]{"uma Fortaleza do Nether", 6}),
            Map.entry("bastion_remnant", new Object[]{"um Bastiao", 6}),
            Map.entry("end_city", new Object[]{"uma Cidade do End", 7}),
            Map.entry("stronghold", new Object[]{"uma Fortaleza (stronghold)", 7}),
            Map.entry("ancient_city", new Object[]{"uma Cidade Antiga", 8}),
            Map.entry("mansion", new Object[]{"uma Mansao da Floresta", 7}),
            Map.entry("monument", new Object[]{"um Monumento Oceanico", 6}),
            Map.entry("pillager_outpost", new Object[]{"um Posto de Saqueadores", 4}),
            Map.entry("trail_ruins", new Object[]{"Ruinas de Trilha", 3}),
            Map.entry("desert_pyramid", new Object[]{"um Templo do Deserto", 3}),
            Map.entry("jungle_pyramid", new Object[]{"um Templo da Selva", 3}),
            Map.entry("igloo", new Object[]{"um Iglu", 3}),
            Map.entry("swamp_hut", new Object[]{"uma Cabana de Bruxa", 3}),
            Map.entry("mineshaft", new Object[]{"uma Mina Abandonada", 2}),
            Map.entry("ruined_portal", new Object[]{"um Portal em Ruinas", 2}));

    public DimensionManager(GODRuntime rt) { this.rt = rt; }

    public static void registerHooks() {
        ServerEntityWorldChangeEvents.AFTER_PLAYER_CHANGE_WORLD.register((player, origin, destination) ->
                GODMod.with(rt -> rt.dimensions.onChangeWorld(player, destination)));
        ServerLivingEntityEvents.ALLOW_DEATH.register((entity, source, amount) -> {
            if (entity instanceof EnderDragonEntity) GODMod.with(rt -> rt.dimensions.onDragonDeath());
            return true;
        });
    }

    void onChangeWorld(ServerPlayerEntity p, ServerWorld dest) {
        String name = p.getGameProfile().getName();
        if (dest.getRegistryKey() == World.NETHER) {
            rt.events.record("DIMENSION", 6, name, name + " entrou no Nether");
        } else if (dest.getRegistryKey() == World.END) {
            rt.events.record("DIMENSION", 7, name, name + " entrou no End");
        } else if (dest.getRegistryKey() == World.OVERWORLD) {
            rt.events.record("DIMENSION", 4, name, name + " voltou ao Overworld");
        } else {
            rt.events.record("DIMENSION", 5, name, name + " entrou na dimensao " + dest.getRegistryKey().getValue());
        }
    }

    void onDragonDeath() {
        rt.events.record("DRAGON", 10, null, "O Ender Dragon foi DERROTADO");
    }

    /** Chamado a cada ciclo de observacao. */
    public void poll() {
        polls++;
        for (ServerPlayerEntity p : rt.server.getPlayerManager().getPlayerList()) {
            if (!p.isAlive() || p.isSpectator()) continue;
            ServerWorld w = p.getServerWorld();
            String name = p.getGameProfile().getName();

            if (w.getRegistryKey() == World.END && !dragonSeen.contains(name)) {
                boolean near = !w.getEntitiesByClass(EnderDragonEntity.class, p.getBoundingBox().expand(160), e -> e.isAlive()).isEmpty();
                if (near) {
                    dragonSeen.add(name);
                    rt.events.record("DRAGON", 8, name, name + " encontrou o Ender Dragon");
                }
            } else if (w.getRegistryKey() != World.END) {
                dragonSeen.remove(name);
            }

            if (polls % 3 == 0) checkStructures(p, w, name);
        }
    }

    private void checkStructures(ServerPlayerEntity p, ServerWorld w, String name) {
        Registry<Structure> reg = w.getRegistryManager().get(RegistryKeys.STRUCTURE);
        for (Structure s : reg) {
            Identifier id = reg.getId(s);
            if (id == null) continue;
            StructureStart start = w.getStructureAccessor().getStructureContaining(p.getBlockPos(), s);
            if (start == null || !start.hasChildren()) continue;
            String path = id.getPath();
            String key = name + "|" + id;
            if (rt.memory.longTerm().data.discoveries.contains(key)) continue;
            rt.memory.longTerm().data.discoveries.add(key);
            rt.memory.markDirty();

            String friendly = path;
            int importance = 2;
            for (Map.Entry<String, Object[]> e : STRUCTURES.entrySet()) {
                if (path.equals(e.getKey())) { friendly = (String) e.getValue()[0]; importance = (Integer) e.getValue()[1]; }
            }
            if (path.startsWith("village")) { friendly = "uma Vila"; importance = 3; }
            else if (path.startsWith("shipwreck") || path.startsWith("ocean_ruin")) { friendly = "destrocos do oceano (" + path + ")"; }
            rt.events.record("STRUCTURE", importance, name, name + " descobriu " + friendly);
        }
    }
}
