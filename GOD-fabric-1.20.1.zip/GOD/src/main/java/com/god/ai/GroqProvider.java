package com.god.ai;

import com.god.config.GODConfig;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;

/**
 * Provedor Groq (API compativel com OpenAI: /chat/completions com tool calling).
 * A chave vem de GODConfig e nunca e escrita em logs nem em mensagens de erro.
 */
public class GroqProvider implements AIProvider {
    private static final Gson GSON = new Gson();
    private static final Set<String> PROTECTED = Set.of("model", "messages", "tools", "stream", "tool_choice");
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();

    @Override public String id() { return "groq"; }

    @Override
    public CompletableFuture<ChatResponse> chat(List<JsonObject> messages, JsonArray tools) {
        GODConfig c = GODConfig.get();
        String key = c.resolveApiKey();
        if (key.isBlank()) {
            return CompletableFuture.failedFuture(new AIException(0, "API Key nao configurada", 0));
        }
        try {
            JsonObject body = new JsonObject();
            body.addProperty("model", c.model);
            JsonArray arr = new JsonArray();
            for (JsonObject m : messages) arr.add(m);
            body.add("messages", arr);
            body.addProperty("temperature", c.temperature);
            body.addProperty("max_tokens", c.maxTokens);
            if (tools != null && tools.size() > 0) {
                body.add("tools", tools);
                body.addProperty("tool_choice", "auto");
            }
            try {
                JsonElement extra = JsonParser.parseString(c.extraParamsJson);
                if (extra.isJsonObject()) {
                    for (Map.Entry<String, JsonElement> e : extra.getAsJsonObject().entrySet()) {
                        if (!PROTECTED.contains(e.getKey())) body.add(e.getKey(), e.getValue());
                    }
                }
            } catch (Exception ignored) { /* parametros extras invalidos sao ignorados */ }

            String base = c.baseUrl.endsWith("/") ? c.baseUrl.substring(0, c.baseUrl.length() - 1) : c.baseUrl;
            HttpRequest req = HttpRequest.newBuilder(URI.create(base + "/chat/completions"))
                    .timeout(Duration.ofSeconds(c.requestTimeoutSeconds))
                    .header("Authorization", "Bearer " + key)
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(GSON.toJson(body), StandardCharsets.UTF_8))
                    .build();
            return http.sendAsync(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8)).thenApply(this::parse);
        } catch (Exception e) {
            return CompletableFuture.failedFuture(new AIException(0, "Requisicao invalida: " + e.getClass().getSimpleName(), 0));
        }
    }

    private ChatResponse parse(HttpResponse<String> resp) {
        int code = resp.statusCode();
        String body = resp.body();
        if (code < 200 || code >= 300) {
            long retry = resp.headers().firstValue("retry-after").map(s -> {
                try { return (long) Math.ceil(Double.parseDouble(s.trim())); } catch (Exception e) { return 0L; }
            }).orElse(0L);
            throw new AIException(code, extractError(body), retry);
        }
        JsonObject root = JsonParser.parseString(body).getAsJsonObject();
        JsonArray choices = root.getAsJsonArray("choices");
        if (choices == null || choices.size() == 0) throw new AIException(0, "Resposta sem 'choices'", 0);
        JsonObject msg = choices.get(0).getAsJsonObject().getAsJsonObject("message");

        String content = null;
        JsonElement ce = msg.get("content");
        if (ce != null && !ce.isJsonNull()) content = ce.getAsString();

        List<ToolCall> calls = new ArrayList<>();
        JsonObject raw = new JsonObject();
        raw.addProperty("role", "assistant");
        if (content != null) raw.addProperty("content", content);
        JsonElement tc = msg.get("tool_calls");
        if (tc != null && tc.isJsonArray() && tc.getAsJsonArray().size() > 0) {
            raw.add("tool_calls", tc);
            for (JsonElement el : tc.getAsJsonArray()) {
                JsonObject o = el.getAsJsonObject();
                JsonObject fn = o.getAsJsonObject("function");
                String name = fn.get("name").getAsString();
                JsonObject args = new JsonObject();
                try {
                    JsonElement a = fn.get("arguments");
                    String s = a == null || a.isJsonNull() ? "" : a.getAsString();
                    if (!s.isBlank()) args = JsonParser.parseString(s).getAsJsonObject();
                } catch (Exception e) {
                    args.addProperty("_parse_error", "argumentos JSON invalidos");
                }
                calls.add(new ToolCall(o.get("id").getAsString(), name, args));
            }
        }
        int pt = 0, ct = 0;
        try {
            JsonObject u = root.getAsJsonObject("usage");
            if (u != null) { pt = u.get("prompt_tokens").getAsInt(); ct = u.get("completion_tokens").getAsInt(); }
        } catch (Exception ignored) { }
        return new ChatResponse(content, raw, calls, pt, ct);
    }

    private static String extractError(String body) {
        try {
            JsonObject o = JsonParser.parseString(body).getAsJsonObject();
            JsonObject err = o.getAsJsonObject("error");
            if (err != null && err.has("message")) {
                String m = err.get("message").getAsString();
                if (err.has("code") && !err.get("code").isJsonNull()) m = err.get("code").getAsString() + ": " + m;
                return m.length() > 300 ? m.substring(0, 300) : m;
            }
        } catch (Exception ignored) { }
        return "erro HTTP sem detalhes";
    }
}
