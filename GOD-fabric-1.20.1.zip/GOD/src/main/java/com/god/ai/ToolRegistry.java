package com.god.ai;

import com.god.GODMod;
import com.god.GODRuntime;
import com.god.actions.ItemActions;
import com.god.actions.PlayerActions;
import com.god.actions.WorldActions;
import com.god.commands.GODCommandManager;
import com.god.config.GODConfig;
import com.god.config.GODConfig.AutonomyLevel;
import com.god.memory.LongTermMemory;
import com.god.util.Json;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.List;
import java.util.Set;

/** Ferramentas que a IA pode chamar. Todas executam na thread principal do servidor. */
public class ToolRegistry {
    /** Ferramentas cujo resultado nao precisa voltar para a IA (encerram o turno sem nova requisicao). */
    public static final Set<String> TERMINAL = Set.of("say", "stay_silent", "remember", "create_plan", "update_plan");

    private final GODRuntime rt;

    public ToolRegistry(GODRuntime rt) { this.rt = rt; }

    private static JsonObject fn(String name, String desc, String params) {
        JsonObject f = new JsonObject();
        f.addProperty("name", name);
        f.addProperty("description", desc);
        f.add("parameters", JsonParser.parseString(params));
        JsonObject t = new JsonObject();
        t.addProperty("type", "function");
        t.add("function", f);
        return t;
    }

    /** Define quais ferramentas a IA enxerga, conforme autonomia, origem do turno e interruptores do World Control. */
    public JsonArray definitions(boolean userInitiated, AutonomyLevel level) {
        GODConfig c = GODConfig.get();
        JsonArray a = new JsonArray();
        a.add(fn("say", "Fala no chat como GOD. target = nome do jogador (mensagem privada) ou 'all'.",
                "{\"type\":\"object\",\"properties\":{\"message\":{\"type\":\"string\"},\"target\":{\"type\":\"string\"}},\"required\":[\"message\"]}"));
        a.add(fn("get_player_info", "Consulta vida, fome, posicao, dimensao, bioma, equipamento, inventario resumido e perigos proximos de um jogador.",
                "{\"type\":\"object\",\"properties\":{\"player\":{\"type\":\"string\"}},\"required\":[\"player\"]}"));
        a.add(fn("get_world_info", "Consulta hora, clima, dificuldade, spawn e jogadores online.",
                "{\"type\":\"object\",\"properties\":{}}"));
        a.add(fn("remember", "Guarda um fato ou preferencia duravel na memoria de longo prazo.",
                "{\"type\":\"object\",\"properties\":{\"text\":{\"type\":\"string\"},\"tags\":{\"type\":\"array\",\"items\":{\"type\":\"string\"}},\"importance\":{\"type\":\"integer\",\"description\":\"1 a 10\"}},\"required\":[\"text\"]}"));
        a.add(fn("recall", "Busca na memoria de longo prazo por palavras-chave.",
                "{\"type\":\"object\",\"properties\":{\"query\":{\"type\":\"string\"}},\"required\":[\"query\"]}"));
        a.add(fn("create_plan", "Cria um plano de varias etapas que ficara pendente ate ser concluido.",
                "{\"type\":\"object\",\"properties\":{\"goal\":{\"type\":\"string\"},\"steps\":{\"type\":\"array\",\"items\":{\"type\":\"string\"}}},\"required\":[\"goal\",\"steps\"]}"));
        a.add(fn("update_plan", "Atualiza o status de um plano pendente.",
                "{\"type\":\"object\",\"properties\":{\"plan_id\":{\"type\":\"string\"},\"status\":{\"type\":\"string\",\"enum\":[\"done\",\"cancelled\",\"pending\"]},\"note\":{\"type\":\"string\"}},\"required\":[\"plan_id\",\"status\"]}"));
        a.add(fn("stay_silent", "Nao fazer nada agora. Use quando nao houver motivo claro para intervir.",
                "{\"type\":\"object\",\"properties\":{\"reason\":{\"type\":\"string\"}}}"));

        boolean mid = userInitiated || level.ordinal() >= AutonomyLevel.MEDIUM.ordinal();
        boolean full = userInitiated || level == AutonomyLevel.HIGH;
        if (mid && c.allowItemGiving) {
            a.add(fn("give_item", "Entrega um item a um jogador (usa /give).",
                    "{\"type\":\"object\",\"properties\":{\"player\":{\"type\":\"string\"},\"item\":{\"type\":\"string\",\"description\":\"id do item, ex: minecraft:bread\"},\"count\":{\"type\":\"integer\"}},\"required\":[\"player\",\"item\"]}"));
        }
        if (mid && c.allowInventoryRecovery) {
            a.add(fn("recover_inventory", "Devolve o inventario que o jogador perdeu na ultima morte (uma unica vez por snapshot).",
                    "{\"type\":\"object\",\"properties\":{\"player\":{\"type\":\"string\"},\"snapshot_id\":{\"type\":\"string\"}},\"required\":[\"player\"]}"));
        }
        if (full && c.allowTeleport) {
            a.add(fn("teleport_player", "Teletransporta um jogador para coordenadas (opcionalmente em outra dimensao).",
                    "{\"type\":\"object\",\"properties\":{\"player\":{\"type\":\"string\"},\"x\":{\"type\":\"number\"},\"y\":{\"type\":\"number\"},\"z\":{\"type\":\"number\"},\"dimension\":{\"type\":\"string\",\"description\":\"ex: minecraft:the_nether\"}},\"required\":[\"player\",\"x\",\"y\",\"z\"]}"));
        }
        if (full && c.allowCommands) {
            a.add(fn("run_command", "Executa QUALQUER comando vanilla do Minecraft 1.20.1 (sem a barra inicial). O resultado volta para voce. Comandos destrutivos podem exigir confirmacao de um administrador.",
                    "{\"type\":\"object\",\"properties\":{\"command\":{\"type\":\"string\"},\"reason\":{\"type\":\"string\"}},\"required\":[\"command\"]}"));
        }
        return a;
    }

    public String execute(TurnContext ctx, AIProvider.ToolCall call) {
        JsonObject a = call.args();
        try {
            return switch (call.name()) {
                case "say" -> say(ctx, a);
                case "run_command" -> runCommand(ctx, a);
                case "give_item" -> giveItem(ctx, a);
                case "teleport_player" -> teleport(ctx, a);
                case "get_player_info" -> PlayerActions.playerInfo(rt, Json.str(a, "player", ctx.focusName));
                case "get_world_info" -> WorldActions.worldInfo(rt.server);
                case "recover_inventory" -> recover(ctx, a);
                case "remember" -> remember(ctx, a);
                case "recall" -> recall(a);
                case "create_plan" -> createPlan(ctx, a);
                case "update_plan" -> updatePlan(a);
                case "stay_silent" -> {
                    ctx.ended = true;
                    ctx.silentReason = Json.str(a, "reason", "sem motivo para intervir");
                    yield "OK: em silencio";
                }
                default -> "ERRO: ferramenta desconhecida '" + call.name() + "'";
            };
        } catch (Exception e) {
            GODMod.LOGGER.warn("Erro na ferramenta {}: {}", call.name(), e.toString());
            return "ERRO: " + e.getMessage();
        }
    }

    private String say(TurnContext ctx, JsonObject a) {
        String msg = Json.str(a, "message", "");
        if (msg.isBlank()) return "ERRO: mensagem vazia";
        if (!ctx.userInitiated && !GODConfig.get().spontaneousChat) return "BLOQUEADO: conversas espontaneas desativadas";
        PlayerActions.say(rt, msg, Json.str(a, "target", ""));
        ctx.spoke = true;
        ctx.actions.add("say");
        return "OK: mensagem enviada";
    }

    private String runCommand(TurnContext ctx, JsonObject a) {
        String cmd = Json.str(a, "command", "");
        GODCommandManager.Result r = rt.commands.submit(cmd, ctx.focusPlayer(), ctx.userInitiated, Json.str(a, "reason", ""));
        ctx.actions.add("/" + Json.cut(cmd, 60));
        return r.toToolString();
    }

    private String giveItem(TurnContext ctx, JsonObject a) {
        String cmd;
        try {
            cmd = ItemActions.giveCommand(Json.str(a, "player", ctx.focusName), Json.str(a, "item", ""), Json.integer(a, "count", 1));
        } catch (IllegalArgumentException e) {
            return "ERRO: " + e.getMessage();
        }
        ctx.actions.add("/" + cmd);
        return rt.commands.submit(cmd, ctx.focusPlayer(), ctx.userInitiated, "give_item").toToolString();
    }

    private String teleport(TurnContext ctx, JsonObject a) {
        String cmd;
        try {
            cmd = ItemActions.teleportCommand(Json.str(a, "player", ctx.focusName), Json.num(a, "x", 0), Json.num(a, "y", 64),
                    Json.num(a, "z", 0), Json.str(a, "dimension", ""));
        } catch (IllegalArgumentException e) {
            return "ERRO: " + e.getMessage();
        }
        ctx.actions.add("/" + cmd);
        return rt.commands.submit(cmd, ctx.focusPlayer(), ctx.userInitiated, "teleport_player").toToolString();
    }

    private String recover(TurnContext ctx, JsonObject a) {
        String name = Json.str(a, "player", ctx.focusName);
        ServerPlayerEntity p = name == null ? null : rt.server.getPlayerManager().getPlayer(name);
        if (p == null) return "ERRO: jogador nao encontrado";
        ctx.actions.add("recover_inventory " + name);
        return rt.recovery.deliver(p, Json.str(a, "snapshot_id", ""));
    }

    private String remember(TurnContext ctx, JsonObject a) {
        String text = Json.str(a, "text", "");
        if (text.isBlank()) return "ERRO: texto vazio";
        LongTermMemory.Entry e = rt.memory.remember("fact", text, Json.strList(a, "tags"), Json.integer(a, "importance", 5), ctx.focusName);
        return "OK: memorizado (id " + e.id + ")";
    }

    private String recall(JsonObject a) {
        List<LongTermMemory.Entry> r = rt.memory.longTerm().retrieve(Json.str(a, "query", ""), 5);
        if (r.isEmpty()) return "Nenhuma memoria relevante.";
        StringBuilder sb = new StringBuilder();
        for (LongTermMemory.Entry e : r) sb.append("[").append(e.id).append("] ").append(Json.cut(e.text, 200)).append("\n");
        return sb.toString().trim();
    }

    private String createPlan(TurnContext ctx, JsonObject a) {
        String goal = Json.str(a, "goal", "");
        if (goal.isBlank()) return "ERRO: objetivo vazio";
        LongTermMemory.Entry e = rt.memory.remember("plan", goal, List.of("plano"), 6, ctx.focusName);
        e.steps = Json.strList(a, "steps");
        rt.memory.markDirty();
        return "OK: plano criado (id " + e.id + ")";
    }

    private String updatePlan(JsonObject a) {
        LongTermMemory.Entry e = rt.memory.longTerm().find(Json.str(a, "plan_id", ""));
        if (e == null || !e.type.equals("plan")) return "ERRO: plano nao encontrado";
        e.status = Json.str(a, "status", "done");
        e.note = Json.str(a, "note", "");
        rt.memory.markDirty();
        return "OK: plano " + e.id + " -> " + e.status;
    }
}
