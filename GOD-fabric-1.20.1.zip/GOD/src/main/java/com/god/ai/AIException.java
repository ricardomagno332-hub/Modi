package com.god.ai;

public class AIException extends RuntimeException {
    public final int status;
    public final long retryAfterSeconds;

    public AIException(int status, String message, long retryAfterSeconds) {
        super(message);
        this.status = status;
        this.retryAfterSeconds = retryAfterSeconds;
    }
}
