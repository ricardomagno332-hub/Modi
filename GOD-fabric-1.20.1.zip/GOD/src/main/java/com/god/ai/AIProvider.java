package com.god.ai;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.util.List;
import java.util.concurrent.CompletableFuture;

/** Abstracao de provedor de IA (formato de chat com ferramentas). */
public interface AIProvider {
    String id();

    CompletableFuture<ChatResponse> chat(List<JsonObject> messages, JsonArray tools);

    record ToolCall(String id, String name, JsonObject args) { }

    record ChatResponse(String content, JsonObject rawMessage, List<ToolCall> toolCalls, int promptTokens, int completionTokens) { }
}
