package com.god.ai;

import com.god.GODMod;
import com.god.config.GODConfig;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Gerencia as requisicoes a IA: assincronas (nunca bloqueiam o servidor), com intervalo minimo
 * entre chamadas, backoff em 429 e uma nova tentativa em falhas transitorias.
 */
public class AIManager {
    public enum State { IDLE, THINKING, ERROR, DISABLED }

    private final AIProvider provider = new GroqProvider();
    private volatile long lastRequestMs;
    private volatile long cooldownUntilMs;

    public volatile State state = State.IDLE;
    public volatile String lastError = "";
    public volatile String lastInteraction = "-";
    public volatile String lastDecision = "-";
    public volatile String lastAction = "-";
    public final AtomicLong requests = new AtomicLong();
    public final AtomicLong tokensUsed = new AtomicLong();

    public CompletableFuture<AIProvider.ChatResponse> request(List<JsonObject> messages, JsonArray tools) {
        GODConfig c = GODConfig.get();
        long now = System.currentTimeMillis();
        long wait = Math.max(Math.max(0, lastRequestMs + c.minSecondsBetweenRequests * 1000L - now), Math.max(0, cooldownUntilMs - now));
        lastRequestMs = now + wait;
        state = State.THINKING;
        return CompletableFuture.supplyAsync(() -> 0, CompletableFuture.delayedExecutor(wait, TimeUnit.MILLISECONDS))
                .thenCompose(x -> attempt(messages, tools, 0));
    }

    private CompletableFuture<AIProvider.ChatResponse> attempt(List<JsonObject> messages, JsonArray tools, int n) {
        requests.incrementAndGet();
        return provider.chat(messages, tools).<CompletableFuture<AIProvider.ChatResponse>>handle((r, e) -> {
            if (e == null) {
                state = State.IDLE;
                lastError = "";
                tokensUsed.addAndGet((long) r.promptTokens() + r.completionTokens());
                return CompletableFuture.completedFuture(r);
            }
            Throwable t = unwrap(e);
            if (t instanceof AIException ae) {
                if (ae.status == 429) {
                    cooldownUntilMs = System.currentTimeMillis() + Math.max(5, ae.retryAfterSeconds) * 1000L;
                }
                boolean retryable = (ae.status == 429 && ae.retryAfterSeconds <= 10)
                        || ae.status >= 500
                        || String.valueOf(ae.getMessage()).contains("tool_use_failed");
                if (n < 1 && retryable) {
                    long delay = Math.max(2, ae.retryAfterSeconds);
                    return CompletableFuture.supplyAsync(() -> 0, CompletableFuture.delayedExecutor(delay, TimeUnit.SECONDS))
                            .thenCompose(x -> attempt(messages, tools, n + 1));
                }
            }
            state = State.ERROR;
            lastError = shortMessage(t);
            GODMod.LOGGER.warn("Falha na requisicao a IA: {}", lastError);
            return CompletableFuture.<AIProvider.ChatResponse>failedFuture(t);
        }).thenCompose(f -> f);
    }

    /** Teste de conexao usado pela tela de configuracao (nao precisa de mundo carregado). */
    public static CompletableFuture<String> testConnection() {
        JsonObject m = Msg.user("Responda somente com a palavra OK.");
        return new GroqProvider().chat(List.of(m), null).thenApply(r -> {
            String c = r.content() == null ? "" : r.content().trim();
            return "resposta do modelo: " + (c.length() > 40 ? c.substring(0, 40) : c);
        });
    }

    public static Throwable unwrap(Throwable e) {
        while ((e instanceof CompletionException || e instanceof java.util.concurrent.ExecutionException) && e.getCause() != null) {
            e = e.getCause();
        }
        return e;
    }

    public static String shortMessage(Throwable t) {
        t = unwrap(t);
        if (t instanceof AIException ae) return ae.status > 0 ? "HTTP " + ae.status + " - " + ae.getMessage() : ae.getMessage();
        String m = t.getMessage();
        return t.getClass().getSimpleName() + (m == null ? "" : ": " + (m.length() > 120 ? m.substring(0, 120) : m));
    }
}
