package com.god.ai;

import com.google.gson.JsonObject;

public final class Msg {
    private Msg() { }

    private static JsonObject of(String role, String content) {
        JsonObject o = new JsonObject();
        o.addProperty("role", role);
        o.addProperty("content", content);
        return o;
    }

    public static JsonObject system(String c) { return of("system", c); }
    public static JsonObject user(String c) { return of("user", c); }

    public static JsonObject tool(String callId, String content) {
        JsonObject o = of("tool", content);
        o.addProperty("tool_call_id", callId);
        return o;
    }
}
