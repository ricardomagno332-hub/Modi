package com.god.ai;

import com.god.GODRuntime;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Estado de um turno de raciocinio do GOD (uma rodada de decisao com varias ferramentas). */
public final class TurnContext {
    public final GODRuntime rt;
    public final MinecraftServer server;
    public final boolean userInitiated;
    public final UUID focusId;
    public final String focusName;

    public boolean ended;
    public boolean spoke;
    public String silentReason = "";
    public final List<String> actions = new ArrayList<>();

    public TurnContext(GODRuntime rt, boolean userInitiated, UUID focusId, String focusName) {
        this.rt = rt;
        this.server = rt.server;
        this.userInitiated = userInitiated;
        this.focusId = focusId;
        this.focusName = focusName;
    }

    public ServerPlayerEntity focusPlayer() {
        return focusId == null ? null : server.getPlayerManager().getPlayer(focusId);
    }
}
