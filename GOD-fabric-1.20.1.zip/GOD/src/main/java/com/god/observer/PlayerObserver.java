package com.god.observer;

import com.god.GODMod;
import com.god.GODRuntime;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityCombatEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.registry.Registries;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.world.GameMode;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Observa jogadores: entrada/saida, morte, combate, mineracao/construcao, perigo e biomas. */
public class PlayerObserver {
    private static final Set<String> VALUABLE = Set.of("diamond_ore", "deepslate_diamond_ore", "ancient_debris",
            "emerald_ore", "deepslate_emerald_ore", "spawner", "budding_amethyst");

    private static final class State {
        String biome;
        long lastDanger;
        long lastHunger;
        final Map<String, Integer> broken = new HashMap<>();
        int placed;
        final Map<String, Integer> kills = new HashMap<>();
        float damage;
        final Set<String> damageSources = new LinkedHashSet<>();
    }

    private final GODRuntime rt;
    private final Map<UUID, State> states = new HashMap<>();

    public PlayerObserver(GODRuntime rt) { this.rt = rt; }

    private State st(ServerPlayerEntity p) { return states.computeIfAbsent(p.getUuid(), k -> new State()); }
    private static String name(ServerPlayerEntity p) { return p.getGameProfile().getName(); }

    /** Registra os callbacks do Fabric uma unica vez; eles delegam ao runtime ativo. */
    public static void registerHooks() {
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> GODMod.with(rt -> rt.playerObserver.onJoin(handler.player)));
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> GODMod.with(rt -> rt.playerObserver.onLeave(handler.player)));
        ServerLivingEntityEvents.ALLOW_DEATH.register((entity, source, amount) -> {
            if (entity instanceof ServerPlayerEntity p) GODMod.with(rt -> rt.playerObserver.onDeath(p, source));
            return true;
        });
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (entity instanceof ServerPlayerEntity p) GODMod.with(rt -> rt.playerObserver.onDamage(p, source, amount));
            return true;
        });
        ServerEntityCombatEvents.AFTER_KILLED_OTHER_ENTITY.register((world, entity, killed) -> {
            if (entity instanceof ServerPlayerEntity p) GODMod.with(rt -> rt.playerObserver.onKill(p, killed));
        });
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, be) -> {
            if (player instanceof ServerPlayerEntity p) {
                String id = Registries.BLOCK.getId(state.getBlock()).getPath();
                GODMod.with(rt -> rt.playerObserver.onBreak(p, id));
            }
        });
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (!world.isClient && player instanceof ServerPlayerEntity p && p.getStackInHand(hand).getItem() instanceof BlockItem) {
                GODMod.with(rt -> rt.playerObserver.st(p).placed++);
            }
            return ActionResult.PASS;
        });
    }

    // ---------- eventos ----------
    void onJoin(ServerPlayerEntity p) {
        states.put(p.getUuid(), new State());
        rt.events.record("JOIN", 5, name(p), name(p) + " entrou no mundo");
    }

    void onLeave(ServerPlayerEntity p) {
        rt.events.record("LEAVE", 2, name(p), name(p) + " saiu do mundo");
        states.remove(p.getUuid());
    }

    void onDeath(ServerPlayerEntity p, DamageSource source) {
        String cause = source.getDeathMessage(p).getString();
        String dim = p.getServerWorld().getRegistryKey().getValue().toString();
        rt.events.record("DEATH", 7, name(p), "MORTE: " + cause + " (" + dim + " " + (int) p.getX() + " " + (int) p.getY() + " " + (int) p.getZ() + ")");
    }

    void onDamage(ServerPlayerEntity p, DamageSource source, float amount) {
        State s = st(p);
        s.damage += amount;
        Entity attacker = source.getAttacker();
        String what = attacker != null ? Registries.ENTITY_TYPE.getId(attacker.getType()).getPath() : source.getType().msgId();
        if (s.damageSources.size() < 4) s.damageSources.add(what);
    }

    void onKill(ServerPlayerEntity p, Entity killed) {
        EntityType<?> type = killed.getType();
        String id = Registries.ENTITY_TYPE.getId(type).getPath();
        if (type == EntityType.WITHER || type == EntityType.WARDEN || type == EntityType.ELDER_GUARDIAN) {
            rt.events.record("BOSS", 8, name(p), name(p) + " derrotou " + id);
            return;
        }
        st(p).kills.merge(id, 1, Integer::sum);
    }

    void onBreak(ServerPlayerEntity p, String blockId) {
        if (VALUABLE.contains(blockId)) rt.events.record("RARE_BLOCK", 4, name(p), name(p) + " minerou " + blockId);
        st(p).broken.merge(blockId, 1, Integer::sum);
    }

    // ---------- polling periodico ----------
    public void poll() {
        long now = System.currentTimeMillis();
        for (ServerPlayerEntity p : rt.server.getPlayerManager().getPlayerList()) {
            State s = st(p);
            if (p.isAlive() && !p.isSpectator()) checkDanger(p, s, now);
            String biome = p.getServerWorld().getBiome(p.getBlockPos()).getKey().map(k -> k.getValue().toString()).orElse("?");
            if (s.biome != null && !s.biome.equals(biome)) rt.events.record("BIOME", 1, name(p), name(p) + " entrou no bioma " + biome);
            s.biome = biome;
            flush(p, s);
        }
    }

    private void checkDanger(ServerPlayerEntity p, State s, long now) {
        boolean creative = p.interactionManager.getGameMode() == GameMode.CREATIVE;
        if (creative) return;
        String reason = null;
        if (p.getHealth() <= 6) reason = "vida critica (" + Math.round(p.getHealth()) + ")";
        else if (p.isInLava()) reason = "dentro da lava";
        else if (p.isOnFire() && p.getHealth() < 10) reason = "pegando fogo com pouca vida";
        else if (p.getAir() < 60 && p.isSubmergedInWater()) reason = "se afogando";
        else if (p.getHealth() < 14) {
            int hostiles = p.getServerWorld().getEntitiesByClass(HostileEntity.class, p.getBoundingBox().expand(12), e -> e.isAlive()).size();
            if (hostiles >= 4) reason = "cercado por " + hostiles + " monstros";
        }
        if (reason != null && now - s.lastDanger > 45_000L) {
            s.lastDanger = now;
            rt.events.record("DANGER", 8, name(p), "PERIGO: " + name(p) + " - " + reason);
        }
        if (p.getHungerManager().getFoodLevel() <= 4 && now - s.lastHunger > 180_000L) {
            s.lastHunger = now;
            rt.events.record("HUNGER", 3, name(p), name(p) + " esta com muita fome");
        }
    }

    private void flush(ServerPlayerEntity p, State s) {
        int killTotal = s.kills.values().stream().mapToInt(Integer::intValue).sum();
        if (s.damage > 0 || killTotal > 0) {
            StringBuilder sb = new StringBuilder(name(p)).append(" em combate:");
            if (s.damage > 0) sb.append(" sofreu ").append(Math.round(s.damage)).append(" de dano (").append(String.join(", ", s.damageSources)).append(");");
            if (killTotal > 0) sb.append(" matou ").append(top(s.kills)).append(";");
            rt.events.record("COMBAT", s.damage >= 12 || killTotal >= 10 ? 5 : 3, name(p), sb.toString());
        }
        int broken = s.broken.values().stream().mapToInt(Integer::intValue).sum();
        if (broken > 0 || s.placed > 0) {
            rt.events.record("BUILD_MINE", broken + s.placed >= 150 ? 4 : 2, name(p),
                    name(p) + " quebrou " + broken + " blocos (" + top(s.broken) + ") e colocou ~" + s.placed);
        }
        s.damage = 0;
        s.damageSources.clear();
        s.kills.clear();
        s.broken.clear();
        s.placed = 0;
    }

    private static String top(Map<String, Integer> m) {
        StringBuilder sb = new StringBuilder();
        m.entrySet().stream().sorted((a, b) -> b.getValue() - a.getValue()).limit(3)
                .forEach(e -> sb.append(e.getKey()).append(" x").append(e.getValue()).append(", "));
        return sb.length() > 2 ? sb.substring(0, sb.length() - 2) : "-";
    }
}
