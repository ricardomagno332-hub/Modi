package com.god.observer;

import com.god.GODRuntime;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.Map;

/** Observa o mundo: mudancas de clima e periodo do dia. */
public class WorldObserver {
    private final GODRuntime rt;
    private final Map<String, Integer> weather = new HashMap<>();
    private int lastPhase = -1;
    private long lastDay = -1;

    public WorldObserver(GODRuntime rt) { this.rt = rt; }

    public void poll() {
        for (ServerWorld w : rt.server.getWorlds()) {
            if (!w.getDimension().hasSkyLight()) continue;
            String key = w.getRegistryKey().getValue().toString();
            int state = w.isThundering() ? 2 : w.isRaining() ? 1 : 0;
            Integer prev = weather.put(key, state);
            if (prev != null && prev != state) {
                String txt = state == 2 ? "Comecou uma tempestade" : state == 1 ? "Comecou a chover" : "O tempo abriu";
                rt.events.record("WEATHER", state == 2 ? 3 : 2, null, txt + " em " + key);
            }
        }
        ServerWorld ow = rt.server.getOverworld();
        if (ow.getRegistryKey() != World.OVERWORLD) return;
        long t = ow.getTimeOfDay();
        long dayTime = t % 24000;
        int phase = dayTime < 12000 ? 0 : dayTime < 13000 ? 1 : dayTime < 23000 ? 2 : 3;
        if (lastPhase != -1 && phase != lastPhase) {
            String txt = switch (phase) {
                case 0 -> "O sol nasceu";
                case 1 -> "O sol esta se pondo";
                case 2 -> "A noite chegou";
                default -> "O amanhecer se aproxima";
            };
            rt.events.record("TIME", phase == 2 ? 2 : 1, null, txt);
        }
        lastPhase = phase;
        long day = t / 24000;
        if (lastDay != -1 && day != lastDay) rt.events.record("TIME", 1, null, "Novo dia no mundo: dia " + day);
        lastDay = day;
    }
}
