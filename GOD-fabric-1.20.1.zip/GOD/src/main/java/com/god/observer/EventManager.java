package com.god.observer;

import com.god.GODRuntime;
import com.god.config.GODConfig;
import com.god.memory.GodEvent;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;

/**
 * Fila de eventos pendentes para a IA. Agrupa, deduplica e limita o volume para nao
 * sobrecarregar o servidor nem a API. Tudo e gravado tambem no historico persistente.
 */
public class EventManager {
    private static final int MAX_PENDING = 60;
    private static final long MAX_AGE_MS = 10 * 60 * 1000L;

    private final GODRuntime rt;
    private final List<GodEvent> pending = new ArrayList<>();

    public EventManager(GODRuntime rt) { this.rt = rt; }

    public void record(String type, int importance, String player, String text) {
        long now = System.currentTimeMillis();
        for (GodEvent e : pending) {
            if (e.type.equals(type) && Objects.equals(e.player, player) && e.text.equals(text) && now - e.time < 30_000) return;
        }
        GodEvent ev = new GodEvent(type, importance, player, text, now);
        pending.add(ev);
        rt.memory.history().add(ev, GODConfig.get().maxEventHistory);
        rt.memory.markDirty();
        while (pending.size() > MAX_PENDING) {
            GodEvent worst = pending.get(0);
            for (GodEvent e : pending) if (e.importance < worst.importance) worst = e;
            pending.remove(worst);
        }
    }

    /** Registra uma acao do proprio GOD no historico (nao gera novo gatilho para a IA). */
    public void logAction(String text) {
        rt.memory.history().add(new GodEvent("ACTION", 1, null, text, System.currentTimeMillis()), GODConfig.get().maxEventHistory);
        rt.memory.markDirty();
    }

    private void purgeOld() {
        long now = System.currentTimeMillis();
        pending.removeIf(e -> now - e.time > MAX_AGE_MS);
    }

    public boolean hasPending() {
        purgeOld();
        return !pending.isEmpty();
    }

    public int maxImportance() {
        int m = 0;
        for (GodEvent e : pending) m = Math.max(m, e.importance);
        return m;
    }

    /** Retorna os eventos mais importantes (ordem cronologica) e limpa a fila. */
    public List<GodEvent> drain(int max) {
        purgeOld();
        List<GodEvent> sorted = new ArrayList<>(pending);
        sorted.sort(Comparator.comparingInt((GodEvent e) -> e.importance).reversed());
        List<GodEvent> top = new ArrayList<>(sorted.subList(0, Math.min(max, sorted.size())));
        top.sort(Comparator.comparingLong(e -> e.time));
        pending.clear();
        return top;
    }
}
