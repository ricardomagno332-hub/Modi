package com.god.memory;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Memoria de longo prazo: fatos, preferencias, planos e descobertas, com recuperacao por relevancia. */
public class LongTermMemory {
    public static class Entry {
        public String id;
        public String type = "fact"; // fact | preference | plan | decision
        public String text;
        public List<String> tags = new ArrayList<>();
        public int importance = 5;
        public String player;
        public long created;
        public long lastAccess;
        public String status;        // planos: pending | done | cancelled
        public List<String> steps;   // planos
        public String note;
    }

    public static class Data {
        public List<Entry> entries = new ArrayList<>();
        public Set<String> discoveries = new LinkedHashSet<>();
        public long nextId = 1;
    }

    private static final Set<String> STOP = Set.of("que", "para", "com", "uma", "dos", "das", "por", "não", "nao",
            "the", "and", "you", "are", "est", "como", "mais", "mas", "foi", "ser", "tem", "seu", "sua");

    public Data data = new Data();

    public Entry add(String type, String text, List<String> tags, int importance, String player) {
        Entry e = new Entry();
        e.id = "m" + data.nextId++;
        e.type = type;
        e.text = text.length() > 500 ? text.substring(0, 500) : text;
        if (tags != null) e.tags = new ArrayList<>(tags);
        e.importance = Math.max(1, Math.min(10, importance));
        e.player = player;
        e.created = e.lastAccess = System.currentTimeMillis();
        if (type.equals("plan")) e.status = "pending";
        data.entries.add(e);
        return e;
    }

    public Entry find(String id) {
        for (Entry e : data.entries) if (e.id.equals(id)) return e;
        return null;
    }

    public boolean remove(String id) { return data.entries.removeIf(e -> e.id.equals(id)); }

    public void clear() { data.entries.clear(); }

    public List<Entry> pendingPlans() {
        List<Entry> out = new ArrayList<>();
        for (Entry e : data.entries) if (e.type.equals("plan") && "pending".equals(e.status)) out.add(e);
        return out;
    }

    public List<Entry> recent(int n) {
        List<Entry> l = new ArrayList<>(data.entries);
        l.sort(Comparator.comparingLong((Entry e) -> e.created).reversed());
        return l.subList(0, Math.min(n, l.size()));
    }

    /** Remove as memorias menos valiosas (baixa importancia, antigas) quando passa do limite. */
    public void prune(int max) {
        while (data.entries.size() > max) {
            Entry worst = null;
            double ws = Double.MAX_VALUE;
            long now = System.currentTimeMillis();
            for (Entry e : data.entries) {
                if (e.type.equals("plan") && "pending".equals(e.status)) continue;
                double age = (now - e.lastAccess) / 86_400_000.0;
                double s = e.importance * 1.0 + 2 * Math.exp(-age / 14.0);
                if (s < ws) { ws = s; worst = e; }
            }
            if (worst == null) return;
            data.entries.remove(worst);
        }
    }

    /** Recuperacao seletiva: so devolve memorias relevantes para a consulta (ou muito importantes). */
    public List<Entry> retrieve(String query, int limit) {
        if (limit <= 0) return List.of();
        Set<String> q = tokens(query);
        long now = System.currentTimeMillis();
        Map<Entry, Double> scored = new HashMap<>();
        for (Entry e : data.entries) {
            if (e.type.equals("plan")) continue;
            Set<String> et = tokens(e.text);
            int overlap = 0;
            for (String w : q) if (et.contains(w)) overlap++;
            int tagHit = 0;
            for (String t : e.tags) if (q.contains(normalize(t))) tagHit++;
            boolean relevant = overlap > 0 || tagHit > 0 || e.importance >= 8;
            if (!relevant) continue;
            double age = (now - e.lastAccess) / 86_400_000.0;
            scored.put(e, overlap * 3.0 + tagHit * 2.5 + e.importance * 0.4 + 2 * Math.exp(-age / 7.0));
        }
        List<Map.Entry<Entry, Double>> list = new ArrayList<>(scored.entrySet());
        list.sort((a, b) -> Double.compare(b.getValue(), a.getValue()));
        List<Entry> out = new ArrayList<>();
        for (int i = 0; i < Math.min(limit, list.size()); i++) {
            Entry e = list.get(i).getKey();
            e.lastAccess = now;
            out.add(e);
        }
        return out;
    }

    static String normalize(String s) {
        if (s == null) return "";
        return Normalizer.normalize(s.toLowerCase(Locale.ROOT), Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
    }

    static Set<String> tokens(String s) {
        Set<String> out = new HashSet<>();
        for (String w : normalize(s).split("[^a-z0-9_]+")) {
            if (w.length() >= 3 && !STOP.contains(w)) out.add(w);
        }
        return out;
    }
}
