package com.god.memory;

import com.god.GODMod;
import com.god.config.GODConfig;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.WorldSavePath;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;

/**
 * Coordena memoria de curto prazo (conversa), longo prazo e historico de eventos.
 * Arquivos ficam em &lt;mundo&gt;/god/ e sobrevivem ao fechamento do Minecraft.
 */
public class MemoryManager {
    public static class ConvMsg {
        public String role;     // user | god
        public String speaker;
        public String text;
        public long time;
    }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final int MAX_CONV = 200;

    private final Path dir;
    private final LongTermMemory longTerm = new LongTermMemory();
    private EventHistory history = new EventHistory();
    private List<ConvMsg> conversation = new ArrayList<>();
    private boolean dirty;

    public MemoryManager(MinecraftServer server) {
        this.dir = server.getSavePath(WorldSavePath.ROOT).resolve("god").normalize();
        load();
    }

    public Path dir() { return dir; }
    public LongTermMemory longTerm() { return longTerm; }
    public EventHistory history() { return history; }
    public void markDirty() { dirty = true; }

    // ---------- API ----------
    public LongTermMemory.Entry remember(String type, String text, List<String> tags, int importance, String player) {
        LongTermMemory.Entry e = longTerm.add(type, text, tags, importance, player);
        longTerm.prune(GODConfig.get().maxLongTermMemories);
        dirty = true;
        return e;
    }

    public void addConversation(String role, String speaker, String text) {
        ConvMsg m = new ConvMsg();
        m.role = role;
        m.speaker = speaker;
        m.text = text.length() > 400 ? text.substring(0, 400) : text;
        m.time = System.currentTimeMillis();
        conversation.add(m);
        while (conversation.size() > MAX_CONV) conversation.remove(0);
        dirty = true;
    }

    public List<ConvMsg> recentConversation(int n) {
        int from = Math.max(0, conversation.size() - n);
        return new ArrayList<>(conversation.subList(from, conversation.size()));
    }

    public void clearHistory() {
        conversation.clear();
        history.clear();
        dirty = true;
    }

    public void clearLongTerm() {
        longTerm.clear();
        dirty = true;
    }

    // ---------- Persistencia ----------
    private void load() {
        GODConfig c = GODConfig.get();
        if (!c.persistentMemory) return;
        try {
            Files.createDirectories(dir);
            Path mem = dir.resolve("memory.json");
            if (Files.exists(mem)) {
                LongTermMemory.Data d = GSON.fromJson(Files.readString(mem, StandardCharsets.UTF_8), LongTermMemory.Data.class);
                if (d != null) longTerm.data = d;
            }
            Path hist = dir.resolve("history.json");
            if (Files.exists(hist)) {
                EventHistory h = GSON.fromJson(Files.readString(hist, StandardCharsets.UTF_8), EventHistory.class);
                if (h != null) history = h;
            }
            Path conv = dir.resolve("conversation.json");
            if (c.saveHistory && Files.exists(conv)) {
                ConvMsg[] arr = GSON.fromJson(Files.readString(conv, StandardCharsets.UTF_8), ConvMsg[].class);
                if (arr != null) conversation = new ArrayList<>(List.of(arr));
            }
        } catch (Exception e) {
            GODMod.LOGGER.error("Falha ao carregar memoria: {}", e.toString());
        }
    }

    public void saveIfDirty() {
        if (dirty) save();
    }

    public synchronized void save() {
        GODConfig c = GODConfig.get();
        if (!c.persistentMemory) { dirty = false; return; }
        try {
            Files.createDirectories(dir);
            atomicWrite(dir.resolve("memory.json"), GSON.toJson(longTerm.data));
            atomicWrite(dir.resolve("history.json"), GSON.toJson(history));
            if (c.saveHistory) atomicWrite(dir.resolve("conversation.json"), GSON.toJson(conversation));
            dirty = false;
        } catch (Exception e) {
            GODMod.LOGGER.error("Falha ao salvar memoria: {}", e.toString());
        }
    }

    /** Escrita atomica (arquivo temporario + move) para nao corromper dados em caso de crash. */
    public static void atomicWrite(Path target, String content) throws IOException {
        Path tmp = target.resolveSibling(target.getFileName() + ".tmp");
        Files.writeString(tmp, content, StandardCharsets.UTF_8);
        try {
            Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (AtomicMoveNotSupportedException e) {
            Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING);
        }
    }
}
