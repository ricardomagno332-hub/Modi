package com.god.memory;

/** Evento observado no mundo (ou acao tomada), com importancia de 1 a 10. */
public class GodEvent {
    public String type;
    public int importance;
    public String player;
    public String text;
    public long time;

    public GodEvent() { }

    public GodEvent(String type, int importance, String player, String text, long time) {
        this.type = type;
        this.importance = importance;
        this.player = player;
        this.text = text;
        this.time = time;
    }
}
