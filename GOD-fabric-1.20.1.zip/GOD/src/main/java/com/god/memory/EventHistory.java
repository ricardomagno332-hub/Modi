package com.god.memory;

import java.util.ArrayList;
import java.util.List;

/** Historico circular de eventos e acoes (persistido em history.json). */
public class EventHistory {
    public List<GodEvent> list = new ArrayList<>();

    public void add(GodEvent e, int max) {
        list.add(e);
        while (list.size() > max) list.remove(0);
    }

    public List<GodEvent> recent(int n, String type) {
        List<GodEvent> out = new ArrayList<>();
        for (int i = list.size() - 1; i >= 0 && out.size() < n; i--) {
            GodEvent e = list.get(i);
            if (type == null || type.equals(e.type)) out.add(0, e);
        }
        return out;
    }

    public void clear() { list.clear(); }
}
