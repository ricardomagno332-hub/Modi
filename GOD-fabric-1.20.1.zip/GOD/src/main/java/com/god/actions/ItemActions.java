package com.god.actions;

import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

import java.util.Locale;
import java.util.regex.Pattern;

/** Montagem validada de comandos de entrega de itens (executados pelo GODCommandManager). */
public final class ItemActions {
    private static final Pattern PLAYER = Pattern.compile("[A-Za-z0-9_]{1,16}");

    private ItemActions() { }

    /** Retorna o comando /give pronto ou lanca IllegalArgumentException com o motivo. */
    public static String giveCommand(String player, String item, int count) {
        if (player == null || !PLAYER.matcher(player).matches()) throw new IllegalArgumentException("nome de jogador invalido");
        if (item == null || item.isBlank()) throw new IllegalArgumentException("item vazio");
        String raw = item.trim().toLowerCase(Locale.ROOT);
        int cut = raw.length();
        int b1 = raw.indexOf('[');
        int b2 = raw.indexOf('{');
        if (b1 >= 0) cut = Math.min(cut, b1);
        if (b2 >= 0) cut = Math.min(cut, b2);
        String idPart = raw.substring(0, cut);
        Identifier id = Identifier.tryParse(idPart);
        if (id == null || !Registries.ITEM.containsId(id)) throw new IllegalArgumentException("item desconhecido: " + idPart);
        int c = Math.max(1, Math.min(2304, count));
        return "give " + player + " " + raw + " " + c;
    }

    public static String teleportCommand(String player, double x, double y, double z, String dimension) {
        if (player == null || !PLAYER.matcher(player).matches()) throw new IllegalArgumentException("nome de jogador invalido");
        String tp = String.format(Locale.ROOT, "tp %s %.2f %.2f %.2f", player, x, y, z);
        if (dimension == null || dimension.isBlank()) return tp;
        if (!dimension.matches("[a-z0-9_.-]+(:[a-z0-9_./-]+)?")) throw new IllegalArgumentException("dimensao invalida");
        return "execute in " + dimension + " run " + tp;
    }
}
