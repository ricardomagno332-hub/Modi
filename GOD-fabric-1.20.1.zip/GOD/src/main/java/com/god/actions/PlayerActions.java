package com.god.actions;

import com.god.GODRuntime;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;

import java.util.Map;
import java.util.TreeMap;

/** Acoes ligadas a jogadores: falar no chat e consultar o estado de um jogador. */
public final class PlayerActions {
    private PlayerActions() { }

    public static void say(GODRuntime rt, String message, String target) {
        String clean = message.replace("**", "").replace("§", "").trim();
        ServerPlayerEntity targetPlayer = null;
        if (target != null && !target.isBlank() && !target.equalsIgnoreCase("all")) {
            targetPlayer = rt.server.getPlayerManager().getPlayer(target);
        }
        for (String line : clean.split("\\R")) {
            if (line.isBlank()) continue;
            if (line.length() > 300) line = line.substring(0, 300);
            Text text = Text.literal("<GOD> ").formatted(Formatting.GOLD, Formatting.BOLD)
                    .append(Text.literal(line).formatted(Formatting.YELLOW));
            if (targetPlayer != null) targetPlayer.sendMessage(text);
            else rt.server.getPlayerManager().broadcast(text, false);
        }
        String who = targetPlayer != null ? targetPlayer.getGameProfile().getName() : "todos";
        rt.ai.lastInteraction = "GOD -> " + who + ": " + (clean.length() > 80 ? clean.substring(0, 80) + "..." : clean);
        rt.memory.addConversation("god", "GOD", clean);
    }

    public static String itemId(ItemStack s) {
        return Registries.ITEM.getId(s.getItem()).toString();
    }

    public static String playerInfo(GODRuntime rt, String name) {
        ServerPlayerEntity p = name == null || name.isBlank() ? null : rt.server.getPlayerManager().getPlayer(name);
        if (p == null) return "ERRO: jogador nao encontrado/online: " + name;
        JsonObject o = new JsonObject();
        o.addProperty("name", p.getGameProfile().getName());
        o.addProperty("health", Math.round(p.getHealth() * 10) / 10.0);
        o.addProperty("food", p.getHungerManager().getFoodLevel());
        o.addProperty("xpLevel", p.experienceLevel);
        o.addProperty("gamemode", p.interactionManager.getGameMode().getName());
        o.addProperty("dimension", p.getServerWorld().getRegistryKey().getValue().toString());
        BlockPos b = p.getBlockPos();
        o.addProperty("pos", b.getX() + " " + b.getY() + " " + b.getZ());
        o.addProperty("biome", p.getServerWorld().getBiome(b).getKey().map(k -> k.getValue().toString()).orElse("?"));
        o.addProperty("onFire", p.isOnFire());
        o.addProperty("air", p.getAir());
        o.addProperty("hostilesWithin12", p.getServerWorld()
                .getEntitiesByClass(HostileEntity.class, p.getBoundingBox().expand(12), e -> e.isAlive()).size());
        JsonArray armor = new JsonArray();
        for (ItemStack s : p.getInventory().armor) if (!s.isEmpty()) armor.add(itemId(s));
        o.add("armor", armor);
        o.addProperty("mainHand", p.getMainHandStack().isEmpty() ? "vazio" : itemId(p.getMainHandStack()));

        Map<String, Integer> counts = new TreeMap<>();
        for (ItemStack s : p.getInventory().main) if (!s.isEmpty()) counts.merge(itemId(s), s.getCount(), Integer::sum);
        for (ItemStack s : p.getInventory().offHand) if (!s.isEmpty()) counts.merge(itemId(s), s.getCount(), Integer::sum);
        JsonObject inv = new JsonObject();
        counts.entrySet().stream()
                .sorted((a, c) -> Integer.compare(c.getValue(), a.getValue()))
                .limit(30)
                .forEach(e -> inv.addProperty(e.getKey(), e.getValue()));
        o.add("inventory", inv);
        o.addProperty("pendingInventorySnapshots", rt.recovery.pendingCount(p.getUuid()));
        return o.toString();
    }
}
