package com.god.actions;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.GameRules;

/** Consultas ao estado do mundo (somente leitura). */
public final class WorldActions {
    private WorldActions() { }

    public static String worldInfo(MinecraftServer server) {
        ServerWorld ow = server.getOverworld();
        JsonObject o = new JsonObject();
        long t = ow.getTimeOfDay();
        o.addProperty("timeOfDay", t % 24000);
        o.addProperty("day", t / 24000);
        o.addProperty("weather", ow.isThundering() ? "tempestade" : ow.isRaining() ? "chuva" : "limpo");
        o.addProperty("difficulty", ow.getDifficulty().getName());
        o.addProperty("keepInventory", server.getGameRules().getBoolean(GameRules.KEEP_INVENTORY));
        BlockPos sp = ow.getSpawnPos();
        o.addProperty("spawn", sp.getX() + " " + sp.getY() + " " + sp.getZ());
        JsonArray players = new JsonArray();
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            players.add(p.getGameProfile().getName() + " (" + p.getServerWorld().getRegistryKey().getValue() + ")");
        }
        o.add("players", players);
        return o.toString();
    }
}
