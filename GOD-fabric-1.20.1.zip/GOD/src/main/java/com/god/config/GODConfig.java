package com.god.config;

import com.god.GODMod;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.PosixFilePermissions;

/** Configuracao global do GOD (config/god.json). Todas as opcoes da UI sao salvas aqui. */
public class GODConfig {
    public enum AutonomyLevel { OFF, LOW, MEDIUM, HIGH }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("god.json");
    private static GODConfig instance = new GODConfig();

    // ---- IA ----
    public String provider = "groq";
    public String baseUrl = "https://api.groq.com/openai/v1";
    public String apiKey = "";
    public String model = "llama-3.3-70b-versatile";
    public double temperature = 0.7;
    public int maxTokens = 1024;
    public String extraParamsJson = "{}";
    public int requestTimeoutSeconds = 40;
    public int minSecondsBetweenRequests = 3;
    public int maxToolStepsPerTurn = 6;

    // ---- Autonomia ----
    public AutonomyLevel autonomy = AutonomyLevel.HIGH;
    public boolean spontaneousChat = true;
    public boolean selfInitiative = true;
    public int observationIntervalSeconds = 5;
    public int decisionIntervalSeconds = 45;
    public int idleInitiativeMinutes = 10;
    public String triggerName = "god";
    public boolean respondToAllChat = false;
    public int conversationWindowSeconds = 90;

    // ---- Memoria ----
    public boolean persistentMemory = true;
    public boolean saveHistory = true;
    public int maxLongTermMemories = 500;
    public int maxEventHistory = 300;
    public int promptMemoryCount = 8;
    public int promptHistoryMessages = 10;

    // ---- Controle do mundo ----
    public boolean allowCommands = true;
    public boolean allowBlockModification = true;
    public boolean allowEntitySummon = true;
    public boolean allowWeatherControl = true;
    public boolean allowItemGiving = true;
    public boolean allowTeleport = true;
    public boolean allowInventoryRecovery = true;
    public boolean requireConfirmationForDestructive = true;
    public boolean confirmWhenAffectingOthers = true;
    public boolean allowServerAdminCommands = false;
    public int maxFillVolume = 4096;
    public int maxCommandsPerMinute = 30;
    public int commandPermissionLevel = 4;
    public int confirmationTimeoutSeconds = 120;

    public static synchronized GODConfig get() { return instance; }

    public static synchronized void load() {
        try {
            if (Files.exists(FILE)) {
                GODConfig c = GSON.fromJson(Files.readString(FILE, StandardCharsets.UTF_8), GODConfig.class);
                if (c != null) instance = c;
            }
            save();
        } catch (Exception e) {
            GODMod.LOGGER.error("Falha ao carregar config/god.json: {}", e.toString());
        }
    }

    public static synchronized void save() {
        try {
            instance.sanitize();
            Path tmp = FILE.resolveSibling("god.json.tmp");
            Files.writeString(tmp, GSON.toJson(instance), StandardCharsets.UTF_8);
            try { Files.setPosixFilePermissions(tmp, PosixFilePermissions.fromString("rw-------")); } catch (Exception ignored) { }
            try {
                Files.move(tmp, FILE, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException e) {
                Files.move(tmp, FILE, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Exception e) {
            GODMod.LOGGER.error("Falha ao salvar config/god.json: {}", e.toString());
        }
    }

    /** Chave da API: arquivo de config ou variavel de ambiente GROQ_API_KEY. Nunca logar este valor. */
    public String resolveApiKey() {
        String k = apiKey == null ? "" : apiKey.trim();
        if (k.isEmpty()) {
            String env = System.getenv("GROQ_API_KEY");
            if (env != null) k = env.trim();
        }
        return k;
    }

    public void sanitize() {
        if (provider == null || provider.isBlank()) provider = "groq";
        if (baseUrl == null || baseUrl.isBlank()) baseUrl = "https://api.groq.com/openai/v1";
        if (apiKey == null) apiKey = "";
        if (model == null || model.isBlank()) model = "llama-3.3-70b-versatile";
        if (extraParamsJson == null || extraParamsJson.isBlank()) extraParamsJson = "{}";
        if (triggerName == null || triggerName.isBlank()) triggerName = "god";
        if (autonomy == null) autonomy = AutonomyLevel.HIGH;
        temperature = Math.max(0, Math.min(2, temperature));
        maxTokens = clamp(maxTokens, 64, 8192);
        requestTimeoutSeconds = clamp(requestTimeoutSeconds, 5, 180);
        minSecondsBetweenRequests = clamp(minSecondsBetweenRequests, 0, 120);
        maxToolStepsPerTurn = clamp(maxToolStepsPerTurn, 1, 15);
        observationIntervalSeconds = clamp(observationIntervalSeconds, 1, 120);
        decisionIntervalSeconds = clamp(decisionIntervalSeconds, 5, 3600);
        idleInitiativeMinutes = clamp(idleInitiativeMinutes, 1, 240);
        conversationWindowSeconds = clamp(conversationWindowSeconds, 10, 900);
        maxLongTermMemories = clamp(maxLongTermMemories, 20, 10000);
        maxEventHistory = clamp(maxEventHistory, 20, 5000);
        promptMemoryCount = clamp(promptMemoryCount, 0, 30);
        promptHistoryMessages = clamp(promptHistoryMessages, 0, 40);
        maxFillVolume = clamp(maxFillVolume, 1, 1_000_000);
        maxCommandsPerMinute = clamp(maxCommandsPerMinute, 1, 600);
        commandPermissionLevel = clamp(commandPermissionLevel, 0, 4);
        confirmationTimeoutSeconds = clamp(confirmationTimeoutSeconds, 15, 3600);
    }

    private static int clamp(int v, int min, int max) { return Math.max(min, Math.min(max, v)); }
}
