package com.god.client;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;

/** Integra a tela de configuracao do GOD ao menu Mods (Mod Menu). */
public class GODModMenu implements ModMenuApi {
    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return GodConfigScreen::new;
    }
}
