package com.god.client;

import com.god.GODMod;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;

import java.util.List;

/** Painel do GOD dentro do mundo (tecla G): estado, ultima interacao/decisao/acao, memorias e atividade. */
public class GodPanelScreen extends Screen {
    private static JsonObject data = new JsonObject();
    private int ticks;

    public GodPanelScreen() { super(Text.literal("GOD - Painel")); }

    public static void update(String json) {
        try {
            data = JsonParser.parseString(json).getAsJsonObject();
        } catch (Exception ignored) { }
    }

    @Override
    protected void init() { request(); }

    @Override
    public void tick() {
        if (++ticks % 40 == 0) request();
    }

    private void request() {
        if (ClientPlayNetworking.canSend(GODMod.STATUS_REQUEST)) {
            ClientPlayNetworking.send(GODMod.STATUS_REQUEST, PacketByteBufs.create());
        }
    }

    @Override
    public boolean shouldPause() { return false; }

    private String s(String k) {
        JsonElement e = data.get(k);
        return e == null || e.isJsonNull() ? "-" : e.getAsString();
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx);
        int x = 20;
        int y = 16;
        ctx.drawTextWithShadow(textRenderer, "\u00a76\u00a7lGOD \u00a7r\u2014 Painel", x, y, 0xFFFFFF);
        y += 16;
        y = line(ctx, "Estado: ", s("state") + "   Autonomia: " + s("autonomy"), x, y);
        y = line(ctx, "Provedor: ", s("provider") + "   Modelo: " + s("model") + "   Chave: " + (data.has("apiKeySet") && data.get("apiKeySet").getAsBoolean() ? "ok" : "FALTANDO"), x, y);
        y = line(ctx, "Ultima interacao: ", s("lastInteraction"), x, y);
        y = line(ctx, "Ultima decisao: ", s("lastDecision"), x, y);
        y = line(ctx, "Ultima acao: ", s("lastAction"), x, y);
        y = line(ctx, "Atividade autonoma: ", s("autonomousTurns") + " turnos | " + s("userTurns") + " respostas | " + s("commandsRun")
                + " comandos | " + s("pending") + " pendentes | " + s("requests") + " req", x, y);
        String err = s("lastError");
        if (!err.isBlank() && !err.equals("-")) y = line(ctx, "\u00a7cErro: ", err, x, y);
        y += 4;
        ctx.drawTextWithShadow(textRenderer, "\u00a7eMemorias recentes:", x, y, 0xFFFFFF);
        y += 12;
        JsonElement m = data.get("memories");
        if (m != null && m.isJsonArray() && ((JsonArray) m).size() > 0) {
            for (JsonElement e : (JsonArray) m) y = line(ctx, "\u00a77- ", e.getAsString(), x, y);
        } else {
            ctx.drawTextWithShadow(textRenderer, "\u00a77(nenhuma / visivel apenas para administradores)", x, y, 0xFFFFFF);
        }
        super.render(ctx, mouseX, mouseY, delta);
    }

    private int line(DrawContext ctx, String label, String value, int x, int y) {
        List<OrderedText> lines = textRenderer.wrapLines(Text.literal("\u00a7e" + label + "\u00a7f" + value), width - 40);
        for (OrderedText l : lines) {
            ctx.drawTextWithShadow(textRenderer, l, x, y, 0xFFFFFF);
            y += 10;
        }
        return y + 2;
    }
}
