package com.god.client;

import com.god.GODMod;
import com.god.GODRuntime;
import com.god.ai.AIManager;
import com.god.config.GODConfig;
import com.god.config.GODConfig.AutonomyLevel;
import com.god.memory.LongTermMemory;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.CyclingButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;
import java.util.function.IntConsumer;

/**
 * Tela de configuracao (menu Mods): AI Settings, Autonomy Settings, Memory Settings e World Control.
 * Tudo e gravado em config/god.json ao trocar de aba ou clicar em "Salvar e fechar".
 */
public class GodConfigScreen extends Screen {
    private static final String[] TABS = {"AI", "Autonomia", "Memoria", "Mundo"};

    private final Screen parent;
    private int tab;
    private String status = "";
    private int cy;
    private final List<Runnable> appliers = new ArrayList<>();
    private final List<Object[]> labels = new ArrayList<>(); // {texto, y}

    public GodConfigScreen(Screen parent) {
        super(Text.literal("GOD - Configuracoes"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        appliers.clear();
        labels.clear();
        int tw = 72;
        int x0 = width / 2 - (TABS.length * (tw + 4)) / 2;
        for (int i = 0; i < TABS.length; i++) {
            final int idx = i;
            ButtonWidget b = ButtonWidget.builder(Text.literal(TABS[i]), btn -> {
                applyAll();
                tab = idx;
                clearChildren();
                init();
            }).dimensions(x0 + i * (tw + 4), 20, tw, 20).build();
            b.active = i != tab;
            addDrawableChild(b);
        }
        cy = 52;
        switch (tab) {
            case 0 -> buildAi();
            case 1 -> buildAutonomy();
            case 2 -> buildMemory();
            default -> buildWorld();
        }
        addDrawableChild(ButtonWidget.builder(Text.literal("Salvar e fechar"), b -> {
            applyAll();
            GODConfig.save();
            client.setScreen(parent);
        }).dimensions(width / 2 - 100, height - 28, 200, 20).build());
    }

    private void applyAll() {
        for (Runnable r : appliers) {
            try { r.run(); } catch (Exception ignored) { }
        }
        GODConfig.save();
    }

    @Override
    public void close() {
        applyAll();
        client.setScreen(parent);
    }

    // ---------- helpers de layout ----------
    private TextFieldWidget field(String label, String value, int maxLen, boolean secret, Consumer<String> apply) {
        int y = cy;
        cy += 24;
        labels.add(new Object[]{label, y + 5});
        TextFieldWidget f = new TextFieldWidget(textRenderer, width / 2 + 10, y, 150, 18, Text.literal(label));
        f.setMaxLength(maxLen);
        f.setText(value == null ? "" : value);
        if (secret) f.setRenderTextProvider((s, off) -> OrderedText.styledForwardsVisitedString("*".repeat(s.length()), Style.EMPTY));
        addDrawableChild(f);
        appliers.add(() -> apply.accept(f.getText()));
        return f;
    }

    private void intField(String label, int value, int min, int max, IntConsumer set) {
        field(label, String.valueOf(value), 7, false, s -> {
            try { set.accept(Math.max(min, Math.min(max, Integer.parseInt(s.trim())))); } catch (NumberFormatException ignored) { }
        });
    }

    private void toggle(String label, boolean value, Consumer<Boolean> set) {
        int y = cy;
        cy += 24;
        addDrawableChild(CyclingButtonWidget.onOffBuilder(value)
                .build(width / 2 - 160, y, 320, 20, Text.literal(label), (b, v) -> set.accept(v)));
    }

    private void button(String label, Runnable action) {
        int y = cy;
        cy += 24;
        addDrawableChild(ButtonWidget.builder(Text.literal(label), b -> action.run()).dimensions(width / 2 - 160, y, 320, 20).build());
    }

    private static class Slider extends SliderWidget {
        private final String label;
        private final double min;
        private final double max;
        private final DoubleConsumer cb;

        Slider(int x, int y, int w, int h, String label, double min, double max, double val, DoubleConsumer cb) {
            super(x, y, w, h, Text.empty(), (val - min) / (max - min));
            this.label = label;
            this.min = min;
            this.max = max;
            this.cb = cb;
            updateMessage();
        }

        @Override protected void updateMessage() {
            setMessage(Text.literal(label + ": " + String.format(Locale.ROOT, "%.2f", min + value * (max - min))));
        }

        @Override protected void applyValue() { cb.accept(min + value * (max - min)); }
    }

    // ---------- abas ----------
    private void buildAi() {
        GODConfig c = GODConfig.get();
        field("Provedor", c.provider, 40, false, s -> c.provider = s.trim());
        field("URL base da API", c.baseUrl, 200, false, s -> c.baseUrl = s.trim());
        field("API Key", c.apiKey, 200, true, s -> c.apiKey = s.trim());
        field("Modelo", c.model, 100, false, s -> c.model = s.trim());
        int y = cy;
        cy += 24;
        addDrawableChild(new Slider(width / 2 - 160, y, 320, 20, "Temperatura", 0, 2, c.temperature, v -> c.temperature = Math.round(v * 100) / 100.0));
        intField("Limite de tokens", c.maxTokens, 64, 8192, v -> c.maxTokens = v);
        field("Parametros extras (JSON)", c.extraParamsJson, 400, false, s -> c.extraParamsJson = s.trim());
        button("Testar conexao", () -> {
            applyAll();
            status = "Testando...";
            AIManager.testConnection().whenComplete((msg, err) -> client.execute(() ->
                    status = err == null ? "\u00a7aOK - " + msg : "\u00a7cFalha: " + AIManager.shortMessage(err)));
        });
    }

    private void buildAutonomy() {
        GODConfig c = GODConfig.get();
        int y = cy;
        cy += 24;
        addDrawableChild(CyclingButtonWidget.<AutonomyLevel>builder(l -> Text.literal(l.name()))
                .values(AutonomyLevel.values()).initially(c.autonomy)
                .build(width / 2 - 160, y, 320, 20, Text.literal("Nivel de autonomia"), (b, v) -> c.autonomy = v));
        toggle("Conversas espontaneas", c.spontaneousChat, v -> c.spontaneousChat = v);
        toggle("Iniciativa propria", c.selfInitiative, v -> c.selfInitiative = v);
        intField("Observacao (s)", c.observationIntervalSeconds, 1, 120, v -> c.observationIntervalSeconds = v);
        intField("Intervalo de decisoes (s)", c.decisionIntervalSeconds, 5, 3600, v -> c.decisionIntervalSeconds = v);
        intField("Iniciativa ociosa (min)", c.idleInitiativeMinutes, 1, 240, v -> c.idleInitiativeMinutes = v);
        field("Nome que chama o GOD", c.triggerName, 30, false, s -> c.triggerName = s.trim());
    }

    private void buildMemory() {
        GODConfig c = GODConfig.get();
        toggle("Memoria persistente", c.persistentMemory, v -> c.persistentMemory = v);
        toggle("Salvar historico de conversa", c.saveHistory, v -> c.saveHistory = v);
        intField("Limite de memorias", c.maxLongTermMemories, 20, 10000, v -> c.maxLongTermMemories = v);
        button("Apagar memoria de longo prazo", () -> {
            GODRuntime rt = GODMod.runtime();
            if (rt == null) { status = "\u00a7eDisponivel apenas com um mundo local aberto (ou use /god memory clear)."; return; }
            rt.memory.clearLongTerm();
            status = "\u00a7aMemoria de longo prazo apagada.";
        });
        button("Apagar historico de conversa/eventos", () -> {
            GODRuntime rt = GODMod.runtime();
            if (rt == null) { status = "\u00a7eDisponivel apenas com um mundo local aberto."; return; }
            rt.memory.clearHistory();
            status = "\u00a7aHistorico apagado.";
        });
        GODRuntime rt = GODMod.runtime();
        if (rt != null) {
            int y = cy;
            for (LongTermMemory.Entry e : rt.memory.longTerm().recent(4)) {
                labels.add(new Object[]{"\u00a77[" + e.id + "] " + (e.text.length() > 60 ? e.text.substring(0, 60) + "..." : e.text), y});
                y += 11;
            }
        }
    }

    private void buildWorld() {
        GODConfig c = GODConfig.get();
        toggle("Acesso aos comandos", c.allowCommands, v -> c.allowCommands = v);
        toggle("Modificacao de blocos", c.allowBlockModification, v -> c.allowBlockModification = v);
        toggle("Invocacao de entidades", c.allowEntitySummon, v -> c.allowEntitySummon = v);
        toggle("Controle climatico", c.allowWeatherControl, v -> c.allowWeatherControl = v);
        toggle("Entrega de itens", c.allowItemGiving, v -> c.allowItemGiving = v);
        toggle("Teletransporte", c.allowTeleport, v -> c.allowTeleport = v);
        toggle("Recuperacao de inventario", c.allowInventoryRecovery, v -> c.allowInventoryRecovery = v);
        toggle("Confirmar acoes destrutivas", c.requireConfirmationForDestructive, v -> c.requireConfirmationForDestructive = v);
        intField("Volume maximo de fill/clone", c.maxFillVolume, 1, 1_000_000, v -> c.maxFillVolume = v);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx);
        ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, 6, 0xFFFFFF);
        for (Object[] l : labels) {
            ctx.drawTextWithShadow(textRenderer, (String) l[0], width / 2 - 160, (Integer) l[1], 0xE0E0E0);
        }
        if (!status.isEmpty()) ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(status), width / 2, height - 42, 0xFFFFFF);
        super.render(ctx, mouseX, mouseY, delta);
    }
}
