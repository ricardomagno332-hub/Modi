package com.god.client;

import com.god.GODMod;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class GODClient implements ClientModInitializer {
    private static KeyBinding openPanel;

    @Override
    public void onInitializeClient() {
        openPanel = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.god.panel", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_G, "category.god"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openPanel.wasPressed()) {
                if (client.player != null && client.currentScreen == null) client.setScreen(new GodPanelScreen());
            }
        });

        ClientPlayNetworking.registerGlobalReceiver(GODMod.STATUS, (client, handler, buf, responseSender) -> {
            String json = buf.readString(32767); // le antes de sair da thread de rede
            client.execute(() -> GodPanelScreen.update(json));
        });
    }
}
