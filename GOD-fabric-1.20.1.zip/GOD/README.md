# GOD — IA autônoma para Minecraft Java 1.20.1 (Fabric)

GOD é uma inteligência (Groq API) que habita o mundo: observa eventos, lembra (memória em JSON), conversa,
planeja e age usando ferramentas e os comandos vanilla reais do Minecraft.

## 1. Gerar o JAR

**Pelo celular/sem instalar nada (GitHub Actions):**
1. Crie um repositório no GitHub e envie todo o conteúdo desta pasta (incluindo `.github/`).
2. Aba **Actions → build → Run workflow** (ou faça um push).
3. Ao terminar, baixe o artefato **god-mod-jar**. Use o `god-1.0.0.jar` (não o `-sources`).

**No PC:** instale JDK 17 e Gradle 8.5, depois rode `gradle build`. O JAR sai em `build/libs/god-1.0.0.jar`.

## 2. Instalar
- Minecraft Java **1.20.1** + **Fabric Loader** (0.14.21+) + **Fabric API 0.92.x**.
- (Recomendado) **Mod Menu** para abrir a tela de configuração.
- Copie `god-1.0.0.jar` para a pasta `mods/`.

## 3. Configurar
Menu **Mods → GOD → Configurar** (abas AI / Autonomia / Memória / Mundo), ou edite `config/god.json`.
- API Key da Groq: crie em console.groq.com. Também aceita a variável de ambiente `GROQ_API_KEY`.
- Modelo padrão: `llama-3.3-70b-versatile` (precisa suportar *tool calling*; troque se a Groq o aposentar).
- Use **Testar conexão** na aba AI.
- Em servidor dedicado, edite `config/god.json` no servidor.

## 4. Usar
- Fale no chat chamando "GOD" (ou use `/god ask <mensagem>`). Ele continua a conversa por ~90 s.
- **G** abre o painel do GOD (estado, última interação/decisão/ação, memórias, atividade).
- Autonomia inicial: **HIGH**. Mude na UI ou com `/god autonomy <OFF|LOW|MEDIUM|HIGH>`.

### Comandos `/god`
`status`, `ask`, `pending`, `confirm <id>`, `deny <id>`, `autonomy`, `reload`, `recover <jogador>`, `memory list|forget <id>|clear`.

## Segurança
- GOD executa qualquer comando vanilla pelo dispatcher real, na thread principal, com nível de permissão configurável.
- Ações destrutivas (kill @a/@e, clear, fill/clone acima do limite, gamerule/worldborder, TNT/Wither/Dragão, afetar outros jogadores)
  exigem **confirmação administrativa** (botões [Aprovar]/[Negar] no chat ou `/god confirm <id>`).
- Comandos de administração do servidor (`op`, `ban`, `stop`, `whitelist`, `datapack`...) ficam bloqueados por padrão
  (`allowServerAdminCommands`) e, se liberados, sempre pedem confirmação.
- A IA não executa código Java nem acessa o sistema operacional; só usa as ferramentas do mod.
- A API Key nunca vai para logs nem para o painel. Ela fica em `config/god.json` (permissão só do dono, quando o SO permite).

## Dados
`<mundo>/god/`: `memory.json` (longo prazo + descobertas), `history.json` (eventos/ações),
`conversation.json` (curto prazo), `recovery.json` (snapshots de inventário).
